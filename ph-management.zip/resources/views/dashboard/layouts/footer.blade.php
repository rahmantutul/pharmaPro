<footer class="inner">
    <div class="footer-inner">
        <div class="pull-left">
            &copy; {{ date('Y') }} {{ Helper::getStoreInfo()->appname }}. {{ __('All rights reserved.') }} | Developed by Rahman Tutul
        </div>
        <div class="pull-right">
            <span class="go-top"><i class="fa fa-chevron-up"></i></span>
        </div>
    </div>
</footer>