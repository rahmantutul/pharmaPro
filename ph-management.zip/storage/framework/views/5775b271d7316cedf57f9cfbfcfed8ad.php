<?php $__env->startSection('template_title'); ?>
    <?php echo e(trans('installer_messages.serverRequirements.templateTitle')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('icontent'); ?>
    <div class="flex">
        <?php echo $__env->make('vendor.installer._inc.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="body-content w-full h-screen">
            <h1 class="capitalize text-primary border-b-[2px] border-[var(--primary)] pl-20 py-5 text-2xl font-semibold mb-4">
                <?php echo e(env('APP_NAME')); ?>

            </h1>
            <div class="h-[80vh] w-full flex flex-col justify-between items-center gap-10 pl-4"  style="background: #ffffffc4; padding: 15px;">
                <div class="content-wrapper w-full">
                    <?php $__currentLoopData = $requirements['requirements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <ul class="listing flex flex-col gap-2 mt-4 px-2">
                            <li class="flex items-center justify-between gap-4 border-b border-[rgba(var(--primary-rgb),0.4)] last:border-b-0 pb-2 <?php echo e($phpSupportInfo['supported'] ? 'success' : 'error'); ?>">
                                <strong class="flex items-center justify-between text-lg no-underline bg-primary text-white font-medium text-start px-6 py-3 mb-6 rounded-[4px] w-full">
                                    <span>
                                        <?php echo e(ucfirst($type)); ?>

                                        <?php if($type == 'php'): ?>
                                            <small>
                                                (<?php echo e(trans('installer_messages.version')); ?> <?php echo e($phpSupportInfo['minimum']); ?> <?php echo e(trans('installer_messages.required')); ?>)
                                            </small>
                                        <?php endif; ?>
                                    </span>
                                    <?php if($type == 'php'): ?>
                                        <span class="flex items-center gap-2">
                                            <strong>
                                                <?php echo e($phpSupportInfo['current']); ?>

                                            </strong>
                                            <?php if($phpSupportInfo['supported']): ?>
                                                <i class="ri-check-double-line"></i>
                                            <?php else: ?>
                                                <i class="ri-close-line"></i>
                                            <?php endif; ?>
                                        </span>
                                    <?php endif; ?>
                                </strong>
                            </li>
                            <?php $__currentLoopData = $requirements['requirements'][$type]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extention => $enabled): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex items-center justify-between gap-4 border-b border-[rgba(var(--primary-rgb),0.4)] last:border-b-0 pb-2 <?php echo e($enabled ? 'success' : 'error'); ?>">
                                    <span class="text-md capitalize text-primary"><?php echo e($extention); ?></span>
                                    <div class="icon text-lg <?php echo e($enabled ? 'text-theme' : 'text-red-400'); ?>">
                                        <?php if($enabled): ?>
                                            <i class="ri-check-double-line"></i>
                                        <?php else: ?>
                                            <i class="ri-close-line"></i>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="flex gap-4 items-center justify-center">
                    <a href="<?php echo e(route('LaravelInstaller::purchase-validation')); ?>" class="btn-primary-outline">
                        <i class="ri-arrow-left-line"></i>
                        <?php echo e(trans('installer_messages.serverRequirements.previous')); ?>

                    </a>
                    <?php if(!isset($requirements['errors']) && $phpSupportInfo['supported'] ): ?>
                        <a href="<?php echo e(route('LaravelInstaller::permissions')); ?>" class="btn-primary-fill">
                            <?php echo e(trans('installer_messages.serverRequirements.next')); ?>

                            <i class="ri-arrow-right-s-line"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.installer.layouts.imaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/vendor/installer/server-requirements.blade.php ENDPATH**/ ?>