

<?php $__env->startPush('stylesheet'); ?>
<style>
    td{
        padding: 2px !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                           <?php echo e(__('Demurrage')); ?>

                        </a>
                    </li>
                    <li class="active">
                        <?php echo e(__('Create')); ?>

                    </li>
                </ol>
            </div>
            <div class="row" style="display:flex;">
                <div class="col-sm-8" style="margin:auto !important;">
                    <div class="panel panel-white">
                        <div class="panel-heading" style="border-bottom: 2px solid #f1f3f5; padding: 20px;">
                            <h4 style="margin: 0; color: #212529; font-weight: 600;">
                                <i class="fa fa-clock-o" style="color: #6c757d;"></i> <?php echo e(__('Create Demurrage')); ?>

                            </h4>
                            <p style="margin: 5px 0 0 0; color: #6c757d; font-size: 14px;"><?php echo e(__('Record demurrage charges for medicines')); ?></p>
                        </div>
                        <div class="panel-body" style="padding: 30px;">
                            <form method="POST" action="<?php echo e(route('demurrage.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="medicine" class="form-label" style="font-weight: 600; color: #495057; margin-bottom: 8px;">
                                            <?php echo e(__('Medicine')); ?> <span style="color: #dc3545;">*</span>
                                        </label>
                                        <select name="medicineId" id="medicine" class="form-control single-select" onchange="getMedicineDetail(this);" required style="height: 42px;">
                                            <option value=""><?php echo e(__('Select Medicine')); ?></option>
                                            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($medicine->id); ?>"><?php echo e($medicine->name); ?> - <?php echo e($medicine->strength); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="demurrage_date" class="form-label" style="font-weight: 600; color: #495057; margin-bottom: 8px;">
                                            <?php echo e(__('Demurrage Date')); ?> <span style="color: #dc3545;">*</span>
                                        </label>
                                        <input type="date" name="demurrage_date" id="demurrage_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required style="height: 42px;">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label for="price" class="form-label" style="font-weight: 600; color: #495057; margin-bottom: 8px;">
                                            <?php echo e(__('Price')); ?> <span style="color: #dc3545;">*</span>
                                        </label>
                                        <input type="number" id="price" name="price" class="form-control" step="0.01" placeholder="0.00" required style="height: 42px;">
                                    </div>
                                    
                                    <div class="col-md-4 mb-3">
                                        <label for="quantity" class="form-label" style="font-weight: 600; color: #495057; margin-bottom: 8px;">
                                            <?php echo e(__('Quantity')); ?> <span style="color: #dc3545;">*</span>
                                        </label>
                                        <input type="number" id="quantity" name="quantity" class="form-control" value="1" placeholder="1" required style="height: 42px;">
                                    </div>
                                    
                                    <div class="col-md-4 mb-3">
                                        <label for="total" class="form-label" style="font-weight: 600; color: #495057; margin-bottom: 8px;">
                                            <?php echo e(__('Total Amount')); ?>

                                        </label>
                                        <input type="number" id="total" name="total" class="form-control total" placeholder="0.00" readonly style="height: 42px; background-color: #e9ecef; font-weight: 600;">
                                    </div>
                                </div>

                                <div class="row mt-4">
                                    <div class="col-md-12" style="border-top: 1px solid #e9ecef; padding-top: 20px;">
                                        <button type="submit" class="btn btn-primary" style="padding: 10px 30px; font-weight: 500;">
                                            <i class="fa fa-save"></i> <?php echo e(__('Save Demurrage')); ?>

                                        </button>
                                        <a href="<?php echo e(route('demurrage.index')); ?>" class="btn btn-secondary" style="padding: 10px 30px; font-weight: 500;">
                                            <i class="fa fa-times"></i> <?php echo e(__('Cancel')); ?>

                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
    <script>
        $(document).ready(function() {
            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>
            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            $('#medicine').select2({
                placeholder: "Select an option", // Optional placeholder
                allowClear: true // Allows user to clear selection
            });
        });
    </script>
    <script>
        $('.single-select').select2({
            theme: 'bootstrap4',
            width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
            placeholder: $(this).data('placeholder'),
            allowClear: Boolean($(this).data('allow-clear')),
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const priceInput = document.getElementById('price');
            const quantityInput = document.getElementById('quantity');
            const totalInput = document.getElementById('total');
    
            function calculateTotal() {
                const price = parseFloat(priceInput.value) || 0;
                const quantity = parseFloat(quantityInput.value) || 0;
                totalInput.value = (price * quantity).toFixed(2);
            }
    
            priceInput.addEventListener('input', calculateTotal);
            quantityInput.addEventListener('input', calculateTotal);
        });

        // Fetch medicine details via AJAX
        function getMedicineDetail(selectElement) {
            let medId = $(selectElement).val();
            if (medId) {
                let url = `<?php echo e(route('medicine.getMedicineDetails')); ?>`;
                $.ajax({
                    url: url,
                    method: 'GET',
                    data: { id: medId },
                    success: function(response) {
                        // Assuming response contains 'price' and 'supplier'
                        const rowId = $(selectElement).attr('id').split('_')[1];
                        $(`#price`).val(response.dataInfo.purchase_price);

                        // Recalculate total if qty is already set
                        const qty = $(`#quantity`).val();
                        if (qty > 0) {
                            const total = qty * response.dataInfo.purchase_price;
                            $(`#total`).val(total);
                        }
                    },
                    error: function() {
                        alert("An error occurred!");
                    }
                });
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/demurrage/create.blade.php ENDPATH**/ ?>