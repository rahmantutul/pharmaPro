

<?php $__env->startPush('stylesheet'); ?>
<style>
    td{
        padding: 2px !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                            <?php echo e(__('Report')); ?>

                        </a>
                    </li>
                    <li class="active">
                        <?php echo e(__('Sales Report')); ?>

                    </li>
                </ol>
            </div>
            <div class="row" style="display:flex;">
                <div class="col-sm-10" style="margin:auto !important;">
                    <div class="panel panel-white">
                        <div class="panel-body">
                          <h4><?php echo e(__('Sales Report')); ?></h4>
                          <div class="row">
                            <form action="" method="GET" id="myform" style="padding:6px;"> <?php echo csrf_field(); ?>
                              <div class="row bg-secondary p-3">
                                  <div class="col-md-2">
                                      <input type="date" class="form-control" id="fromDate" value="<?php echo e(request()->fromDate); ?>" name="fromDate">
                                  </div>
                                  <div class="col-md-2">
                                      <input type="date" class="form-control" id="toDate" name="toDate" value="<?php echo e(request()->toDate); ?>">
                                  </div>
                                  <div class="col-md-4">
                                      <select id="customer" class="form-control single-select" name="customerId">
                                          <option value="">Select Customer</option>
                                          <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option <?php echo e((request()->customerId == $customer->id ? 'selected' : '')); ?> value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                  </div>
                                    <div class="col-md-2">
                                      <button id="btn1" type="submit" name="submit" value="search" class="btn btn-sm btn-primary" title="Search"><i class="fa fa-search"></i></button>
                                      <button id="btn2" type="submit" name="submit" value="pdf" target="__blank" class="btn btn-sm btn-warning" title="Download PDF"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></button>
                                      <a href="<?php echo e(route('report.sales')); ?>" class="btn btn-sm btn-danger" title="Reset"><i class="fa fa-times"></i></a>
                                  </div>
                              </div>
                          </form>
                          </div>
                          <table class="table table-striped table-data table-view">
                            <thead>
                                <tr>
                                    <th scope="col"><?php echo e(__('#')); ?></th>
                                    <th scope="col" style="text-align: center;"><?php echo e(__('Date')); ?></th>
                                    <th scope="col" style="text-align: center;"><?php echo e(__('Invoice')); ?></th>
                                    <th scope="col" style="text-align: center;"><?php echo e(__('Customer')); ?></th>
                                    <th scope="col" style="text-align: center;"><?php echo e(__('Subtotal')); ?></th>
                                    <th scope="col" style="text-align: center;"><?php echo e(__('Inv. Discount')); ?></th>
                                    <th scope="col" style="text-align: center;"><?php echo e(__('Total')); ?></th>
                                    <th scope="col" style="text-align: center;"><?php echo e(__('Paid Amount')); ?></th>
                                    <th scope="col" style="text-align: center;"><?php echo e(__('Invoice Due')); ?></th>
                                </tr>
                            </thead>
                            <?php
                                $total = 0;
                                $totalDiscount = 0;
                                $payableTotal = 0;
                                $paidTotal = 0;
                                $dueTotal = 0;
                            ?>
                            <tbody>
                                <?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $total += $data->grand_total;
                                        $totalDiscount += $data->invoice_discount;
                                        $payableTotal += $data->payable_total;
                                        $paidTotal += $data->paid_amount;
                                        $dueTotal += $data->due_amount;
                                    ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td class="text-bold-500 text-center">
                                            <?php echo e(date('j F Y', strtotime($data->invoice_date))); ?></td>
                                        <td align="center"><?php echo e($data->invoice_no); ?></td>
                                        <td align="center"><?php echo e($data->customer?->name ?? 'Walking customer'); ?></td>
                                        <td align="center"><?php echo e(number_format($data->grand_total, 2)); ?></td>
                                        <td align="center"><?php echo e(number_format($data->invoice_discount, 2)); ?></td>
                                        <td align="center"><?php echo e(number_format($data->payable_total, 2)); ?></td>
                                        <td align="center"><?php echo e(number_format($data->paid_amount, 2)); ?></td>
                                        <td align="center"><?php echo e(number_format($data->due_amount, 2)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <div class="text-center">
                            <?php echo e($dataList->appends(request()->input())->links()); ?>

                        </div>
                                <!-- Professional Summary Card -->
                                <div class="row mt-4">
                                    <div class="col-md-12">
                                        <div class="panel panel-white" style="border-left: 4px solid #3498db;">
                                            <div class="panel-heading" style="background-color: #f8f9fa; border-bottom: 2px solid #e9ecef;">
                                                <h5 class="panel-title" style="color: #2c3e50; font-weight: 600;">
                                                    <i class="fa fa-calculator"></i> <?php echo e(__('Summary (All Matching Records)')); ?>

                                                </h5>
                                            </div>
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-md-2 col-sm-6 mb-3">
                                                        <div class="summary-item" style="text-align: center; padding: 15px; background: #ecf0f1; border-radius: 8px;">
                                                            <small class="text-muted d-block mb-1"><?php echo e(__('Subtotal')); ?></small>
                                                            <h4 class="mb-0" style="color: #34495e; font-weight: 700;"><?php echo e(number_format($grandStats->total_amount, 2)); ?></h4>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-6 mb-3">
                                                        <div class="summary-item" style="text-align: center; padding: 15px; background: #fff3cd; border-radius: 8px;">
                                                            <small class="text-muted d-block mb-1"><?php echo e(__('Invoice Discount')); ?></small>
                                                            <h4 class="mb-0" style="color: #856404; font-weight: 700;"><?php echo e(number_format($grandStats->total_discount, 2)); ?></h4>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3 col-sm-6 mb-3">
                                                        <div class="summary-item" style="text-align: center; padding: 15px; background: #d1ecf1; border-radius: 8px; border: 2px solid #3498db;">
                                                            <small class="text-muted d-block mb-1"><?php echo e(__('Payable Total')); ?></small>
                                                            <h4 class="mb-0" style="color: #0c5460; font-weight: 700;"><?php echo e(number_format($grandStats->payable_total, 2)); ?></h4>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-6 mb-3">
                                                        <div class="summary-item" style="text-align: center; padding: 15px; background: #d4edda; border-radius: 8px;">
                                                            <small class="text-muted d-block mb-1"><?php echo e(__('Paid Amount')); ?></small>
                                                            <h4 class="mb-0" style="color: #155724; font-weight: 700;"><?php echo e(number_format($grandStats->paid_total, 2)); ?></h4>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3 col-sm-6 mb-3">
                                                        <div class="summary-item" style="text-align: center; padding: 15px; background: #f8d7da; border-radius: 8px;">
                                                            <small class="text-muted d-block mb-1"><?php echo e(__('Total Due')); ?></small>
                                                            <h4 class="mb-0" style="color: #721c24; font-weight: 700;"><?php echo e(number_format($grandStats->due_total, 2)); ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
    <script>
        $(document).ready(function() {
            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>
            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            $('#customer').select2({
              placeholder: "Select an option", // Optional placeholder
              allowClear: true // Allows user to clear selection
          });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/reports/sales_report.blade.php ENDPATH**/ ?>