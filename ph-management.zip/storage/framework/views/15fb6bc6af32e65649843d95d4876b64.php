<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/font-awesome/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/invoice.css')); ?>">
    </head>
    <body>
        <div class="invoice-wrapper" id="print-area">
            <div class="invoice">
                <div class="invoice-container">
                    <div class="invoice-head">
                        <div class="invoice-head-top">
                            <div class="invoice-head-top-left text-start">
                                <img src="<?php echo e(asset('uploads/images/settings/' . Helper::getStoreInfo()->logo)); ?>">
                            </div>
                            <div class="invoice-head-top-right text-end">
                                <h3><?php echo e(__('Purchase Invoice')); ?></h3>
                            </div>
                        </div>
                        <div class="hr"></div>
                        <div class="invoice-head-middle">
                            <div class="invoice-head-middle-left text-start">
                                <p><span class="text-bold"><?php echo e(__('Date')); ?>:</span> <?php echo e($dataInfo->created_at->format('F j, Y, g:i A')); ?></p>
                            </div>
                            <div class="invoice-head-middle-right text-end">
                                <p><span class="text-bold" style="text-transform: uppercase"><?php echo e(__('Invoice No')); ?>:</span> <?php echo e($dataInfo->invoice_no); ?></p>
                            </div>
                        </div>
                        <div class="hr"></div>
                        <div class="invoice-head-bottom">
                            <div class="invoice-head-bottom-left">
                                <ul>
                                    <li class="text-bold"><?php echo e(__('Invoiced To')); ?>:</li>
                                    <li><?php echo e(Helper::getStoreInfo()->appname); ?></li>
                                    <li><?php echo e(Helper::getStoreInfo()->address); ?></li>
                                    <li><?php echo e(Helper::getStoreInfo()->phone); ?></li>
                                    <li><?php echo e(Helper::getStoreInfo()->email); ?></li>
                                </ul>
                            </div>
                            <div class="invoice-head-bottom-right">
                                <?php
                                    $supplier = optional($dataInfo->details->first())->medicine->supplier ?? 'No Supplier';
                                ?>
                                <ul class="text-end">
                                    <li class="text-bold"><?php echo e(__('Pay To')); ?>:</li>
                                    <li><?php echo e($supplier->name); ?></li>
                                    <li><?php echo e($supplier->address); ?></li>
                                    <li><?php echo e($supplier->phone); ?></li>
                                    <li><?php echo e($supplier->email); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="overflow-view">
                        <div class="invoice-body">
                            <table>
                                <thead>
                                    <tr>
                                        <td><?php echo e(__('Medicine Name')); ?></td>
                                        <td><?php echo e(__('Strength')); ?></td>
                                        <td><?php echo e(__('Supplier')); ?></td>
                                        <td><?php echo e(__('Price')); ?></td>
                                        <td><?php echo e(__('Quantity')); ?></td>
                                        <td><?php echo e(__('Total')); ?></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $subtotal = 0; 
                                    ?>
                                    <?php $__currentLoopData = $dataInfo->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $subtotal +=  $item->total;
                                    ?>
                                    <tr>
                                        <td><?php echo e($item->medicine->name); ?></td>
                                        <td><?php echo e($item->medicine->strength); ?></td>
                                        <td><?php echo e($item->medicine->supplier->name); ?></td>
                                        <td><?php echo e($item->price); ?></td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e($item->total); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="invoice-body-bottom">
                                <div class="invoice-body-info-item border-bottom">
                                    <div class="info-item-td text-end text-bold"><?php echo e(__('Sub Total')); ?>:</div>
                                    <div class="info-item-td text-end"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e($subtotal); ?></div>
                                </div>
                                <div class="invoice-body-info-item border-bottom">
                                    <div class="info-item-td text-end text-bold"><?php echo e(__('Discount')); ?>:</div>
                                    <div class="info-item-td text-end"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e($dataInfo->total_discount); ?></div>
                                </div>
                                <div class="invoice-body-info-item border-bottom">
                                    <div class="info-item-td text-end text-bold"><?php echo e(__('Total')); ?>:</div>
                                    <div class="info-item-td text-end"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e($dataInfo->total_amount); ?></div>
                                </div>
                                <div class="invoice-body-info-item border-bottom">
                                    <div class="info-item-td text-end text-bold"><?php echo e(__('Paid Amount')); ?>:</div>
                                    <div class="info-item-td text-end"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e($dataInfo->paid_amount); ?></div>
                                </div>
                                <div class="invoice-body-info-item">
                                    <div class="info-item-td text-end text-bold"><?php echo e(__('Due Amount')); ?>:</div>
                                    <div class="info-item-td text-end"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e($dataInfo->due_amount); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="invoice-foot text-center">
                        <p><span class="text-bold text-center"><?php echo e(__('NOTE:')); ?>&nbsp;</span><?php echo e(__('This is a computer-generated receipt and does not require a physical signature.')); ?></p>
        
                        <div class="invoice-btns">
                            <button type="button" class="invoice-btn" onclick="printInvoice()">
                                <span>
                                    <i class="fa fa-print"></i>
                                </span>
                                <span><?php echo e(__('Print')); ?></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>        
        <script>
            function printInvoice(){
                window.print();
            }
        </script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/purchase/print_invoice.blade.php ENDPATH**/ ?>