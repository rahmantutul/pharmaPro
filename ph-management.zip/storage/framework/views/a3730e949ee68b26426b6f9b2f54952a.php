

<?php $__env->startPush('stylesheet'); ?>
<style>
    td{
        padding: 2px !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                            <?php echo e(__('Stock')); ?>

                        </a>
                    </li>
                    <li class="active">
                        <?php echo e(__('In Stock Medicines')); ?>

                    </li>
                </ol>
            </div>
            <div class="row" style="display:flex;">
                <div class="col-sm-10" style="margin:auto !important;">
                    <div class="panel panel-white">
                        <div class="panel-body">
                            <div class="row" style="padding:6px;">
                                <form action="" method="GET" id="myform"> <?php echo csrf_field(); ?>
                                    <div class="row bg-secondary p-3">
                                        <div class="col-md-3">
                                            <select id="medicine" class="form-control single-select" name="medicineId">
                                                <option value=""<?php echo e(__('>Select Medicine')); ?></option>
                                                <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e((request()->medicineId == $medicine->id ? 'selected' : '')); ?> value="<?php echo e($medicine->id); ?>"><?php echo e($medicine->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <button id="btn1" type="submit" name="submit" value="search" class="btn btn-sm btn-primary" title="Search"><i class="fa fa-search"></i></button>
                                            <a href="<?php echo e(route('stock.in_stock')); ?>" class="btn btn-sm btn-danger" title="Reset"><i class="fa fa-times"></i></a>                                        
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col"><?php echo e(__('#')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Medicine')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Strength')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Category')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Supplier')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Total Remining Qty')); ?></th>
                                    </tr>
                                </thead>
                                <?php
                                    $total=0; 
                                ?>
                                <tbody>
                                    <?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $total += $data->total_qty;
                                    ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td class="text-center"><b><?php echo e($data?->medicine->name); ?></b></td>
                                        <td class="text-center"><?php echo e($data?->medicine->strength); ?></td>
                                        <td class="text-center"><?php echo e($data?->medicine?->category?->name); ?></td>
                                        <td class="text-center"><?php echo e($data?->medicine?->supplier?->name); ?></td>
                                        <td class="text-center"><b><?php echo e($data->total_qty); ?></b></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <td colspan="5"></td>
                                    <td class="text-center"><b><?php echo e($total); ?></b></td>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
    <script>
        $(document).ready(function() {
            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>
            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });
        $('#medicine').select2({
            placeholder: "Select an option", // Optional placeholder
            allowClear: true // Allows user to clear selection
        });
        $('#supplier').select2({
            placeholder: "Select an option", // Optional placeholder
            allowClear: true // Allows user to clear selection
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/stock/in_stock.blade.php ENDPATH**/ ?>