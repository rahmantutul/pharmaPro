<style>
.toolbar {
    background: #ffffff;
    border-bottom: 1px solid #eef2f5;
    padding: 12px 20px;
    margin-bottom: 25px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}

.toolbar-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.toolbar-title h4 {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
    color: #333;
}

.toolbar-actions {
    display: flex;
    align-items: center;
    gap: 10px;
}

.toolbar-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 15px;
    background: #f8f9fa;
    border: 1px solid #e0e6ed;
    border-radius: 4px;
    color: #4c5667;
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
    transition: all 0.2s ease;
}

.toolbar-btn:hover {
    background: #eef2f5;
    color: #5D9CEC;
    text-decoration: none;
}

.toolbar-dropdown {
    position: relative;
    display: inline-block;
}

.toolbar-dropdown-menu {
    position: absolute;
    top: 100%;
    right: 0;
    margin-top: 5px;
    background: #fff;
    border: 1px solid #e0e6ed;
    border-radius: 4px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    min-width: 180px;
    opacity: 0;
    visibility: hidden;
    transition: all 0.2s;
    z-index: 1000;
}

.toolbar-dropdown:hover .toolbar-dropdown-menu {
    opacity: 1;
    visibility: visible;
}

.toolbar-dropdown-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 15px;
    color: #555;
    text-decoration: none;
    font-size: 13px;
}

.toolbar-dropdown-item:hover {
    background: #f8f9fa;
    color: #5D9CEC;
    text-decoration: none;
}

.pos-btn {
    background: #5D9CEC;
    border: 1px solid #5D9CEC;
    color: #fff;
}

.pos-btn:hover {
    background: #4a89dc;
    color: #fff;
}
</style>

<div class="toolbar">
    <div class="toolbar-container">
        <div class="toolbar-title">
            <h4><?php echo e(__('Panel Workspace')); ?></h4>
        </div>
        <div class="toolbar-actions">
            <!-- Create Dropdown -->
            <?php if(auth()->guard('admin')->user()->can('customers') || auth()->guard('admin')->user()->can('suppliers') || auth()->guard('admin')->user()->can('medicine-list')): ?>
            <div class="toolbar-dropdown">
                <a href="javascript:void(0)" class="toolbar-btn">
                    <i class="fa fa-plus"></i> <?php echo e(__('Create')); ?> <i class="fa fa-caret-down"></i>
                </a>
                <div class="toolbar-dropdown-menu">
                    <?php if(auth()->guard('admin')->user()->can('customers')): ?>
                    <a href="<?php echo e(route('customer.index')); ?>" class="toolbar-dropdown-item"><i class="fa fa-users"></i> <?php echo e(__('Customer')); ?></a>
                    <?php endif; ?>
                    <?php if(auth()->guard('admin')->user()->can('suppliers')): ?>
                    <a href="<?php echo e(route('supplier.index')); ?>" class="toolbar-dropdown-item"><i class="fa fa-truck"></i> <?php echo e(__('Supplier')); ?></a>
                    <?php endif; ?>
                    <?php if(auth()->guard('admin')->user()->can('medicine-list')): ?>
                    <a href="<?php echo e(route('medicine.index')); ?>" class="toolbar-dropdown-item"><i class="fa fa-medkit"></i> <?php echo e(__('Medicine')); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Reports Dropdown -->
            <?php if(auth()->guard('admin')->user()->can('reports-module')): ?>
            <div class="toolbar-dropdown">
                <a href="javascript:void(0)" class="toolbar-btn">
                    <i class="fa fa-file-text-o"></i> <?php echo e(__('Reports')); ?> <i class="fa fa-caret-down"></i>
                </a>
                <div class="toolbar-dropdown-menu">
                    <?php if(auth()->guard('admin')->user()->can('sales-report')): ?>
                    <a href="<?php echo e(route('report.sales')); ?>" class="toolbar-dropdown-item"><i class="fa fa-line-chart"></i> <?php echo e(__('Sales Report')); ?></a>
                    <?php endif; ?>
                    <?php if(auth()->guard('admin')->user()->can('purchase-report')): ?>
                    <a href="<?php echo e(route('report.purchase')); ?>" class="toolbar-dropdown-item"><i class="fa fa-file-text"></i> <?php echo e(__('Purchase Report')); ?></a>
                    <?php endif; ?>
                    <?php if(auth()->guard('admin')->user()->can('customer-due-report')): ?>
                    <a href="<?php echo e(route('report.customer_due')); ?>" class="toolbar-dropdown-item"><i class="fa fa-credit-card"></i> <?php echo e(__('Customer Due')); ?></a>
                    <?php endif; ?>
                    <?php if(auth()->guard('admin')->user()->can('supplier-due-report')): ?>
                    <a href="<?php echo e(route('report.supplier_due')); ?>" class="toolbar-dropdown-item"><i class="fa fa-truck"></i> <?php echo e(__('Supplier Due')); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Security/System Dropdown -->
            <?php if(auth()->guard('admin')->user()->can('user-management') || auth()->guard('admin')->user()->can('role-permission')): ?>
            <div class="toolbar-dropdown">
                <a href="javascript:void(0)" class="toolbar-btn">
                    <i class="fa fa-cog"></i> <?php echo e(__('Manage')); ?> <i class="fa fa-caret-down"></i>
                </a>
                <div class="toolbar-dropdown-menu">
                    <?php if(auth()->guard('admin')->user()->can('user-management')): ?>
                    <a href="<?php echo e(route('admin.index')); ?>" class="toolbar-dropdown-item"><i class="fa fa-user"></i> <?php echo e(__('Admins')); ?></a>
                    <?php endif; ?>
                    <?php if(auth()->guard('admin')->user()->can('role-permission')): ?>
                    <a href="<?php echo e(route('role.index')); ?>" class="toolbar-dropdown-item"><i class="fa fa-shield"></i> <?php echo e(__('Roles')); ?></a>
                    <?php endif; ?>
                    <?php if(auth()->guard('admin')->user()->can('clear-cache')): ?>
                    <a href="<?php echo e(route('cache.clear')); ?>" class="toolbar-dropdown-item"><i class="fa fa-refresh"></i> <?php echo e(__('Clear Cache')); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if(auth()->guard('admin')->user()->can('sales-order-create')): ?>
            <a href="<?php echo e(route('sales.order.create')); ?>" class="toolbar-btn pos-btn">
                <i class="fa fa-calculator"></i> <?php echo e(__('POS')); ?>

            </a>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/layouts/toolbar.blade.php ENDPATH**/ ?>