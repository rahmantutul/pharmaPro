

<?php $__env->startPush('stylesheet'); ?>
<style>
    .filter-card { background: #ffffff; padding: 20px; border-radius: 8px; border: 1px solid #eef2f7; box-shadow: 0 2px 4px rgba(0,0,0,0.02); margin-bottom: 25px; }
    .stats-card { background: #ffffff; color: #333; padding: 25px; border-radius: 12px; border: 1px solid #eef2f7; box-shadow: 0 4px 6px rgba(0,0,0,0.03); margin-bottom: 25px; }
    .stat-item { text-align: center; border-right: 1px solid #f1f5f9; }
    .stat-item:last-child { border-right: none; }
    .stat-value { font-size: 28px; font-weight: 700; color: #1e293b; }
    .stat-label { font-size: 13px; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 5px; }
    .action-btn-group { display: flex; gap: 4px; }
    .table-hover tbody tr:hover { background-color: #f8fafc; }
    .bg-light-professional { background-color: #fcfdfe !important; }
    .table thead th { background-color: #f1f5f9 !important; color: #475569 !important; font-weight: 600 !important; border-bottom: 2px solid #e2e8f0 !important; }
    .badge-info { background-color: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; font-weight: 500; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="row">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li><a href="#">Sales Management</a></li>
                <li class="active">Sales Returns</li>
            </ol>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row">
        <div class="col-md-12">
            <div class="stats-card">
                <div class="row">
                    <div class="col-md-4">
                        <div class="stat-item">
                            <div class="stat-value"><?php echo e($totalReturns ?? $dataList->total()); ?></div>
                            <div class="stat-label">Total Returns</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-item">
                                    <div class="stat-value"><?php echo e(Helper::getStoreInfo()->currency); ?><?php echo e(number_format($totalAmount ?? 0, 2)); ?></div>
                            <div class="stat-label">Total Amount</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-item">
                            <div class="stat-value"><?php echo e($dataList->count()); ?></div>
                            <div class="stat-label">Showing Results</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-white">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <i class="fa fa-undo"></i> Sales Returns List
                        <a href="<?php echo e(route('return.sales.create')); ?>" class="btn btn-sm btn-success pull-right">
                            <i class="fa fa-plus"></i> Create New Return
                        </a>
                    </h4>
                </div>
                
                <div class="panel-body">
                    <!-- Filter Section -->
                    <div class="filter-card">
                        <form action="<?php echo e(route('return.sales.index')); ?>" method="GET" id="filterForm">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Medicine</label>
                                        <select name="medId" class="form-control" id="medicineFilter">
                                            <option value="">-- All Medicines --</option>
                                            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($med->id); ?>" 
                                                    <?php echo e(request('medId') == $med->id ? 'selected' : ''); ?>>
                                                    <?php echo e($med->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Customer</label>
                                        <select name="customerId" class="form-control" id="customerFilter">
                                            <option value="">-- All Customers --</option>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cust): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cust->id); ?>"
                                                    <?php echo e(request('customerId') == $cust->id ? 'selected' : ''); ?>>
                                                    <?php echo e($cust->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Invoice No</label>
                                        <input type="text" name="invNo" class="form-control" 
                                               placeholder="Search invoice" value="<?php echo e(request('invNo')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>From Date</label>
                                        <input type="date" name="date_from" class="form-control" 
                                               value="<?php echo e(request('date_from')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>To Date</label>
                                        <input type="date" name="date_to" class="form-control" 
                                               value="<?php echo e(request('date_to')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-1">
                                    <div class="form-group">
                                        <label>&nbsp;</label>
                                        <button type="submit" class="btn btn-primary btn-block">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('return.sales.index')); ?>" class="btn btn-sm btn-default">
                                        <i class="fa fa-refresh"></i> Reset Filters
                                    </a>
                                    <button type="button" class="btn btn-sm btn-success" id="exportExcel">
                                        <i class="fa fa-file-excel-o"></i> Export Excel
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- Table Section -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover" id="dataTable">
                            <thead>
                                <tr>
                                    <th width="5%">#</th>
                                    <th width="12%">Invoice No</th>
                                    <th width="10%">Date</th>
                                    <th width="18%">Medicine</th>
                                    <th width="12%">Customer</th>
                                    <th width="8%">Qty</th>
                                    <th width="10%">Price</th>
                                    <th width="10%">Total</th>
                                    <th width="10%">Reason</th>
                                    <th width="5%">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($dataList->firstItem() + $key); ?></td>
                                        <td>
                                            <strong><?php echo e($item->inv_no); ?></strong>
                                        </td>
                                        <td><?php echo e(date('d M Y', strtotime($item->return_date))); ?></td>
                                        <td>
                                            <div>
                                                <strong><?php echo e($item->medicine->name ?? 'N/A'); ?></strong><br>
                                                <small class="text-muted">
                                                    <?php echo e($item->medicine->generic_name ?? ''); ?>

                                                </small>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if($item->customer): ?>
                                                <div>
                                                    <?php echo e($item->customer->name); ?><br>
                                                    <small class="text-muted"><?php echo e($item->customer->phone); ?></small>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">Walk-in</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge badge-info"><?php echo e($item->qty); ?></span>
                                        </td>
                                        <td class="text-right"><?php echo e(Helper::getStoreInfo()->currency); ?><?php echo e(number_format($item->price, 2)); ?></td>
                                        <td class="text-right">
                                            <strong><?php echo e(Helper::getStoreInfo()->currency); ?><?php echo e(number_format($item->total, 2)); ?></strong>
                                        </td>
                                        <td>
                                            <small><?php echo e($item->return_reason ?? '-'); ?></small>
                                        </td>
                                        <td>
                                            <div class="action-btn-group">
                                                <a href="<?php echo e(route('return.sales.show', $item->id)); ?>" 
                                                   class="btn btn-xs btn-info" title="View Details">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                                <form action="<?php echo e(route('return.sales.destroy', $item->id)); ?>" 
                                                      method="POST" class="delete-form" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="button" class="btn btn-xs btn-danger delete-btn" 
                                                            title="Delete">
                                                        <i class="fa fa-trash-o"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="10" class="text-center">
                                            <div style="padding: 40px;">
                                                <i class="fa fa-inbox fa-3x text-muted"></i>
                                                <p class="text-muted" style="margin-top: 10px;">No sales returns found</p>
                                                <a href="<?php echo e(route('return.sales.create')); ?>" class="btn btn-sm btn-success">
                                                    <i class="fa fa-plus"></i> Create First Return
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if($dataList->hasPages()): ?>
                        <div class="text-center">
                            <?php echo e($dataList->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
<script>
$(document).ready(function() {
    // Show messages
    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>", 'Success');
    <?php endif; ?>

    <?php if(session('error')): ?>
        toastr.error("<?php echo e(session('error')); ?>", 'Error');
    <?php endif; ?>

    // Initialize Select2
    $('#medicineFilter, #customerFilter').select2({
        placeholder: "Select an option",
        allowClear: true,
        width: '100%'
    });

    // Delete confirmation
    $('.delete-btn').on('click', function(e) {
        e.preventDefault();
        const form = $(this).closest('.delete-form');
        
        Swal.fire({
            title: 'Are you sure?',
            text: "This will delete the return and restore stock!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });

    // Export to Excel
    $('#exportExcel').on('click', function() {
        const table = document.getElementById('dataTable');
        const wb = XLSX.utils.table_to_book(table, {sheet: "Sales Returns"});
        XLSX.writeFile(wb, 'sales_returns_' + new Date().getTime() + '.xlsx');
    });

    // Print functionality
    window.onbeforeprint = function() {
        document.querySelector('.filter-card').style.display = 'none';
        document.querySelector('.panel-heading').style.display = 'none';
    };

    window.onafterprint = function() {
        document.querySelector('.filter-card').style.display = 'block';
        document.querySelector('.panel-heading').style.display = 'block';
    };
});
</script>

<!-- Include XLSX library for Excel export -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/return/sales_return_index.blade.php ENDPATH**/ ?>