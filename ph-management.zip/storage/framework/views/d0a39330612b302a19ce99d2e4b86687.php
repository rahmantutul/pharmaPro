<?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($dataList->firstItem() + $key); ?></td>
    <td class="text-bold-500"><?php echo e(date('d M, Y h:i A', strtotime($data->invoice_date))); ?></td>
    <td><?php echo e($data->invoice_no); ?></td>
    <td>
        <?php if($data->customer): ?>
            <?php echo e($data?->customer?->name); ?>

        <?php else: ?>
           <?php echo e(__('Walking Customer')); ?>

        <?php endif; ?>
        
    </td>
    <td align="right"><?php echo e($general_setting->currency); ?><?php echo e($data->grand_total); ?></td>
    <td align="right"><?php echo e($general_setting->currency); ?><?php echo e($data->invoice_discount); ?></td>
    <td align="right"><?php echo e($general_setting->currency); ?><?php echo e($data->payable_total); ?></td>
    <td align="right"><?php echo e($general_setting->currency); ?><?php echo e($data->paid_amount); ?></td>
    <td align="right"><?php echo e($general_setting->currency); ?><?php echo e($data->due_amount); ?></td>
    <td>
        <a href="#" data-toggle="modal" data-id="<?php echo e($data->id); ?>" data-target="#medicineModal" class="btn btn-sm btn-success actionButton"><i class="fa fa-eye"></i></a>
        <a href="<?php echo e(route('sales.order.invoice')); ?>?id=<?php echo e($data->id); ?>" class="btn btn-sm btn-primary"><i class="fa fa-file-text-o"></i></a>
        <a href="<?php echo e(route('sales.order.invoice.download')); ?>?id=<?php echo e($data->id); ?>" class="btn btn-sm btn-danger"><i class="fa fa-file-pdf-o"></i> PDF</a>
        <a href="<?php echo e(route('sales.order.destroy', $data->id)); ?>" onclick="return confirm('Are you sure you want to delete this sale?')" class="btn btn-sm btn-danger"><i class="fa fa-trash-o"></i></a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td colspan="10" align="center">
        <?php echo $dataList->links(); ?>

    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/sale/sales_list_partial.blade.php ENDPATH**/ ?>