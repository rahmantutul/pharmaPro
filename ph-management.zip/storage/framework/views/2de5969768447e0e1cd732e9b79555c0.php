

<?php $__env->startPush('stylesheet'); ?>
<style>
    td{
        padding: 2px !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                            <?php echo e(__('Return Management')); ?>

                        </a>
                    </li>
                    <li class="active">
                        <?php echo e(__('Return List')); ?>

                    </li>
                </ol>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-body">
                            <h4><?php echo e(__('Purchase Return')); ?><span class="text-bold"> <?php echo e(__('List')); ?></span></h4>
                            <div class="table-responsive">
                                <div class="row" >
                                    <form action="" method="GET"> <?php echo csrf_field(); ?>
                                        <div class="form-group col-md-4">
                                            <select id="medList" name="medId" class="form-control single-select">
                                                <option value=""><?php echo e(__('Select Medicine')); ?> </option>
                                                <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(($item->id == request()->medId) ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?> || <?php echo e($item->strength); ?> || <?php echo e($item->supplier->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <select id="invoiceList" name="invNo" class="form-control single-select">
                                                <option value=""><?php echo e(__('Select Invoice')); ?> </option>
                                                <?php $__currentLoopData = $invList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->inv_no); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <button class="btn btn-sm btn-primary" type="submit"><i class="fa fa-search"></i>&nbsp; <?php echo e(__('Search')); ?></button>
                                            <a class="btn btn-sm btn-warning" href="<?php echo e(route('return.purchase.index')); ?>"><i class="fa fa-times"></i>&nbsp;<?php echo e(__('Clear')); ?></a>
                                        </div>
                                    </form>
                                </div>
                                <table class="table table-striped" >
                                    <thead>
                                        <tr>
                                            <th class="text-center" scope="col"><?php echo e(__('Return ID')); ?></th>
                                            <th class="text-center" scope="col"><?php echo e(__('Medicine Name')); ?></th>
                                            <th class="text-center" scope="col"><?php echo e(__('Strength')); ?></th>
                                            <th class="text-center" scope="col"><?php echo e(__('Supplier')); ?></th>
                                            <th class="text-center" scope="col"><?php echo e(__('Price')); ?></th>
                                            <th class="text-center" scope="col"><?php echo e(__('Quantity')); ?></th>
                                            <th class="text-center" scope="col"><?php echo e(__('Total')); ?></th>
                                            <th class="text-center" scope="col"><?php echo e(__('Action')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl=> $dataInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th class="text-center"><?php echo e($dataInfo->inv_no ?? 'N/A'); ?></th>
                                                <td class="text-center"><?php echo e($dataInfo->medicine->name); ?></td>
                                                <td class="text-center"><?php echo e($dataInfo->medicine->strength); ?></td>
                                                <td class="text-center"><?php echo e($dataInfo->supplier?->name ?? 'No supplier'); ?></td>
                                                <td class="text-center"><?php echo e(number_format($dataInfo->price, 2)); ?></td>
                                                <td class="text-center"><?php echo e($dataInfo->qty); ?></td>
                                                <td class="text-center"><?php echo e(number_format($dataInfo->total, 2)); ?></td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('return.purchase.show', $dataInfo->id)); ?>" class="btn btn-sm btn-info" title="View"><i class="fa fa-eye"></i></a>
                                                    <a class="btn btn-danger btn-sm" href="<?php echo e(route('return.purchase.destroy',$dataInfo->id)); ?>" onclick="return confirm('Are you sure you want to delete?');"><i class="fa fa-trash-o icon-trash"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="text-center">
                                    <?php echo e($dataList->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
    <script>
        // Initialize the first medicine dropdown
        $(`#medList`).select2({
            placeholder: "Select an option",
            allowClear: true
        });

        // Initialize the first medicine dropdown
        $(`#invoiceList`).select2({
            placeholder: "Select an option",
            allowClear: true
        });

        $(document).ready(function() {
            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>
            <?php if(session('errors')): ?>
                toastr.success("<?php echo e(session('errors')); ?>", 'Errors');
            <?php endif; ?>
            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/return/purchase_return_index.blade.php ENDPATH**/ ?>