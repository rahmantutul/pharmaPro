<footer class="inner">
    <div class="footer-inner">
        <div class="pull-left">
            &copy; <?php echo e(date('Y')); ?> <?php echo e(Helper::getStoreInfo()->appname); ?>. <?php echo e(__('All rights reserved.')); ?> | Developed by Rahman Tutul
        </div>
        <div class="pull-right">
            <span class="go-top"><i class="fa fa-chevron-up"></i></span>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/layouts/footer.blade.php ENDPATH**/ ?>