
<?php $__env->startPush('stylesheet'); ?>
<style>
    /* Custom Modern Dashboard Styles */
    :root {
        --primary-color: #5D9CEC;
        --success-color: #8CC152;
        --info-color: #4AA3DF;
        --warning-color: #F6BB42;
        --danger-color: #DA4453;
        --purple-color: #967ADC;
        --text-muted: #656565;
        --card-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }
    
    .dashboard-header-title {
        font-family: 'Raleway', sans-serif;
        font-weight: 700;
        color: #444;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 20px;
        font-size: 16px;
        border-left: 4px solid var(--primary-color);
        padding-left: 10px;
    }

    /* Modern Cards */
    .dashboard-card {
        background: #fff;
        border-radius: 8px;
        border: none;
        box-shadow: var(--card-shadow);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        margin-bottom: 25px;
        position: relative;
        overflow: hidden;
    }
    .dashboard-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    .card-body {
        padding: 20px;
    }
    
    /* Stats Layout */
    .stat-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .stat-icon {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        color: #fff;
    }
    .stat-content h5 {
        margin: 0 0 5px 0;
        color: var(--text-muted);
        font-size: 13px;
        text-transform: uppercase;
        font-weight: 600;
    }
    .stat-content h3 {
        margin: 0;
        font-size: 22px;
        font-weight: 700;
        color: #333;
    }

    /* Colors */
    .stat-icon.bg-primary { background-color: #5D9CEC !important; background-color: var(--primary-color) !important; }
    .stat-icon.bg-success { background-color: #8CC152 !important; background-color: var(--success-color) !important; }
    .stat-icon.bg-info { background-color: #4AA3DF !important; background-color: var(--info-color) !important; }
    .stat-icon.bg-warning { background-color: #F6BB42 !important; background-color: var(--warning-color) !important; }
    .stat-icon.bg-danger { background-color: #DA4453 !important; background-color: var(--danger-color) !important; }
    .stat-icon.bg-purple { background-color: #967ADC !important; background-color: var(--purple-color) !important; }
    
    /* Table Panels */
    .table-panel {
        background: #fff;
        border-radius: 8px;
        box-shadow: var(--card-shadow);
        border: none;
        margin-bottom: 25px;
    }
    .table-panel .panel-heading {
        background: transparent;
        padding: 15px 20px;
        border-bottom: 1px solid #eee;
    }
    .table-panel .panel-title {
        font-weight: 700;
        color: #333;
        display: flex;
        align-items: center;
    }
    .table-panel .panel-title i, .table-panel .panel-title img {
        margin-right: 10px;
    }
    
    .table-modern thead th {
        border-top: none;
        border-bottom: 2px solid #eee;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 11px;
        color: #888;
        padding: 12px;
    }
    .table-modern tbody td {
        padding: 12px;
        border-top: 1px solid #f9f9f9;
        vertical-align: middle;
        font-size: 13px;
    }
    .table-modern tbody tr:hover {
        background-color: #fcfcfc;
    }

    /* Utilities for BS3 compatibility */
    .mb-0 { margin-bottom: 0 !important; }
    .mb-1 { margin-bottom: 5px !important; }
    .mb-2 { margin-bottom: 10px !important; }
    .mb-3 { margin-bottom: 15px !important; }
    .mt-3 { margin-top: 15px !important; }
    .mt-4 { margin-top: 20px !important; }
    .p-3 { padding: 15px !important; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        <div class="row">
            <div class="col-md-12">
                <hr style="border-top: 1px solid #eaeaea;">
                <h4 class="dashboard-header-title"><?php echo e(__('Overview Statistics')); ?></h4>
            </div>
            
            <div class="col-md-3 col-sm-6">
                <div class="dashboard-card">
                    <div class="card-body">
                        <div class="stat-row">
                            <div class="stat-content">
                                <h5><?php echo e(__('Total Purchase')); ?></h5>
                                <h3><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($purchase, 2)); ?></h3>
                            </div>
                            <div class="stat-icon bg-info">
                                <i class="fa fa-shopping-cart"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dashboard-card">
                    <div class="card-body">
                        <div class="stat-row">
                            <div class="stat-content">
                                <h5><?php echo e(__('Total Sales')); ?></h5>
                                <h3><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($sale, 2)); ?></h3>
                            </div>
                            <div class="stat-icon bg-success">
                                <i class="fa fa-money"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dashboard-card">
                    <div class="card-body">
                        <div class="stat-row">
                            <div class="stat-content">
                                <h5><?php echo e(__('Total Due')); ?></h5>
                                <h3><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($due, 2)); ?></h3>
                            </div>
                            <div class="stat-icon bg-warning">
                                <i class="fa fa-exclamation-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dashboard-card">
                    <div class="card-body">
                        <div class="stat-row">
                            <div class="stat-content">
                                <h5><?php echo e(__('Total Expense')); ?></h5>
                                <h3><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($expense, 2)); ?></h3>
                            </div>
                            <div class="stat-icon bg-danger">
                                <i class="fa fa-minus-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row">
            <div class="col-md-12">
                <h4 class="dashboard-header-title mt-4"><?php echo e(__('Periodic Breakdown')); ?></h4>
            </div>

            
            <div class="col-md-6">
                <div class="table-panel">
                    <div class="panel-heading">
                        <h4 class="panel-title"><i class="fa fa-calendar-check-o text-success"></i> <?php echo e(__('This Month')); ?></h4>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-6 mb-3">
                                <div class="dashboard-card mb-0" style="background: #f9f9f9; box-shadow: none; border: 1px solid #eee;">
                                    <div class="card-body text-center p-3">
                                        <h5 class="text-muted mb-1"><?php echo e(__('Purchase')); ?></h5>
                                        <b class="text-info"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($this_month_purchase, 2)); ?></b>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 mb-3">
                                <div class="dashboard-card mb-0" style="background: #f9f9f9; box-shadow: none; border: 1px solid #eee;">
                                    <div class="card-body text-center p-3">
                                        <h5 class="text-muted mb-1"><?php echo e(__('Sale')); ?></h5>
                                        <b class="text-success"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($this_month_sale, 2)); ?></b>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 mt-3">
                                <div class="dashboard-card mb-0" style="background: #f9f9f9; box-shadow: none; border: 1px solid #eee;">
                                    <div class="card-body text-center p-3">
                                        <h5 class="text-muted mb-1"><?php echo e(__('Due')); ?></h5>
                                        <b class="text-warning"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($this_month_due, 2)); ?></b>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 mt-3">
                                <div class="dashboard-card mb-0" style="background: #f9f9f9; box-shadow: none; border: 1px solid #eee;">
                                    <div class="card-body text-center p-3">
                                        <h5 class="text-muted mb-1"><?php echo e(__('Expense')); ?></h5>
                                        <b class="text-danger"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($this_month_expense, 2)); ?></b>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-6">
                <div class="table-panel">
                    <div class="panel-heading">
                        <h4 class="panel-title"><i class="fa fa-calendar text-primary"></i> <?php echo e(__('This Year')); ?></h4>
                    </div>
                    <div class="panel-body">
                         <div class="row">
                            <div class="col-xs-6 mb-3">
                                <div class="dashboard-card mb-0" style="background: #f9f9f9; box-shadow: none; border: 1px solid #eee;">
                                    <div class="card-body text-center p-3">
                                        <h5 class="text-muted mb-1"><?php echo e(__('Purchase')); ?></h5>
                                        <b class="text-info"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($this_year_purchase, 2)); ?></b>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 mb-3">
                                <div class="dashboard-card mb-0" style="background: #f9f9f9; box-shadow: none; border: 1px solid #eee;">
                                    <div class="card-body text-center p-3">
                                        <h5 class="text-muted mb-1"><?php echo e(__('Sale')); ?></h5>
                                        <b class="text-success"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($this_year_sale, 2)); ?></b>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 mt-3">
                                <div class="dashboard-card mb-0" style="background: #f9f9f9; box-shadow: none; border: 1px solid #eee;">
                                    <div class="card-body text-center p-3">
                                        <h5 class="text-muted mb-1"><?php echo e(__('Due')); ?></h5>
                                        <b class="text-warning"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($this_year_due, 2)); ?></b>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6 mt-3">
                                <div class="dashboard-card mb-0" style="background: #f9f9f9; box-shadow: none; border: 1px solid #eee;">
                                    <div class="card-body text-center p-3">
                                        <h5 class="text-muted mb-1"><?php echo e(__('Expense')); ?></h5>
                                        <b class="text-danger"><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($this_year_expense, 2)); ?></b>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row">
            
            <div class="col-md-6">
                <div class="table-panel">
                    <div class="panel-heading">
                        <h4 class="panel-title text-danger">
                            <i class="fa fa-exclamation-triangle"></i>
                            <?php echo e(__('Expired Medicines')); ?>

                        </h4>
                    </div>
                    <div class="panel-body no-padding">
                        <div class="table-responsive">
                            <table class="table table-modern mb-0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(__('Medicine')); ?></th>
                                        <th><?php echo e(__('Batch')); ?></th>
                                        <th class="text-center"><?php echo e(__('Qty')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $expired_medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><b class="text-dark"><?php echo e($data?->medicine->name); ?></b> <br> <small class="text-muted"><?php echo e($data?->medicine->strength); ?></small></td>
                                        <td><?php echo e(date('d M Y',strtotime($data->expire_date))); ?></td>
                                        <td class="text-center"><span class="label-modern bg-danger text-black"><?php echo e($data->total_qty); ?></span></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center p-3">
                            <?php echo e($expired_medicine->appends(request()->except('page_expired'))->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-6">
                <div class="table-panel">
                    <div class="panel-heading">
                        <h4 class="panel-title text-warning">
                            <i class="fa fa-clock-o"></i>
                             <?php echo e(__('Expiring Soon')); ?> (<?php echo e(Helper::getStoreInfo()->expiryalert); ?> days)
                        </h4>
                    </div>
                    <div class="panel-body no-padding">
                        <div class="table-responsive">
                            <table class="table table-modern mb-0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(__('Medicine')); ?></th>
                                        <th><?php echo e(__('Supplier')); ?></th>
                                        <th class="text-center"><?php echo e(__('Qty')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $upcoming_expire_medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><b class="text-dark"><?php echo e($data?->medicine->name); ?></b> <br> <small class="text-muted"><?php echo e($data?->medicine->strength); ?></small></td>
                                        <td><?php echo e($data?->medicine?->supplier?->name); ?></td>
                                        <td class="text-center"><span class="label-modern bg-warning text-white"><?php echo e($data->total_qty); ?></span></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center p-3">
                            <?php echo e($upcoming_expire_medicine->appends(request()->except('page_upcoming'))->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            
            <div class="col-md-6">
                <div class="table-panel">
                    <div class="panel-heading">
                        <h4 class="panel-title text-success"><i class="fa fa-trophy"></i> <?php echo e(__('Top Sold Medicines')); ?></h4>
                    </div>
                    <div class="panel-body no-padding">
                        <div class="table-responsive">
                            <table class="table table-modern mb-0">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('Medicine')); ?></th>
                                        <th><?php echo e(__('Supplier')); ?></th>
                                        <th class="text-right"><?php echo e(__('Total Qty')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $top_sold_medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><b class="text-dark"><?php echo e($med->medicine?->name); ?></b> <br> <small class="text-muted"><?php echo e($med->medicine?->strength); ?></small></td>
                                        <td><?php echo e($med->medicine?->supplier->name); ?></td>
                                        <td class="text-right"><b><?php echo e(number_format($med->total_quantity, 0)); ?></b></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="3" class="text-center"><?php echo e(__('No data found')); ?></td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center p-3">
                            <?php echo e($top_sold_medicines->appends(request()->except('page_sold'))->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-6">
                <div class="table-panel">
                    <div class="panel-heading">
                        <h4 class="panel-title text-info"><i class="fa fa-users"></i> <?php echo e(__('Top Customers')); ?></h4>
                    </div>
                    <div class="panel-body no-padding">
                        <div class="table-responsive">
                            <table class="table table-modern mb-0">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('Customer')); ?></th>
                                        <th><?php echo e(__('Contact')); ?></th>
                                        <th class="text-right"><?php echo e(__('Total Spent')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $top_buying_customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><b class="text-dark"><?php echo e($customer->customer?->name); ?></b></td>
                                        <td><?php echo e($customer->customer?->phone); ?></td>
                                        <td class="text-right"><b><?php echo e(Helper::getStoreInfo()->currency); ?> <?php echo e(number_format($customer->total_spent, 2)); ?></b></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="3" class="text-center"><?php echo e(__('No data found')); ?></td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center p-3">
                            <?php echo e($top_buying_customers->appends(request()->except('page_customers'))->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('javascript'); ?>
    <script>
        $(document).ready(function() {
            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>

            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/pages/index.blade.php ENDPATH**/ ?>