<?php $__env->startSection('template_title'); ?>
    <?php echo e(trans('installer_messages.configurationSetting.templateTitle')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('icontent'); ?>
    <div class="flex">
        <?php echo $__env->make('vendor.installer._inc.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="body-content w-full h-screen ">
            <h1 class="capitalize text-primary border-b-[2px] border-[var(--primary)] pl-20 py-5 text-2xl font-semibold mb-4">
                <?php echo e(env('APP_NAME')); ?>

            </h1>
            <form method="post" action="<?php echo e(route('LaravelInstaller::environmentSaveWizard')); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="tab" value="configuration">

                <div class="h-[80vh] w-full flex flex-col justify-between items-center gap-10 pl-4"  style="background: #ffffffc4; padding: 15px;">
                    <div class="content-wrapper w-full">
                        <?php echo $__env->make('vendor.installer._inc.environment-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="card bg-white p-6 w-full rounded-md space-y-4">
                            <div class="contact-form">
                                <label for="app_name" class="text-primary block text-sm font-semibold text-gray-700 capitalize">
                                    <?php echo e(trans('installer_messages.environment.wizard.form.app_name_label')); ?>

                                </label>
                                <input
                                    name="app_name"
                                    id="app_name"
                                    value="<?php echo e(env('APP_NAME')); ?>"
                                    class="h-10 px-0 py-3 mt-1 block w-full border-b border-primary outline-none sm:text-sm"
                                    placeholder="<?php echo e(trans('installer_messages.environment.wizard.form.app_name_placeholder')); ?>"
                                />
                                <?php if($errors->has('app_name')): ?>
                                    <span class="text-red">
                                        <?php echo e($errors->first('app_name')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="contact-form">
                                <label class="text-primary block text-sm font-semibold text-gray-700 capitalize">
                                    <?php echo e(trans('installer_messages.environment.wizard.form.app_environment_label')); ?>

                                </label>
                                <select
                                    class="h-10 px-0 py-3 mt-1 block w-full border-b border-primary outline-none sm:text-sm bg-transparent"
                                    name="environment"
                                    id="environment"
                                >
                                    <option value="local" <?php echo e(env('APP_ENV') == 'local' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_environment_label_local')); ?>

                                    </option>
                                    <option value="development" <?php echo e(env('APP_ENV') == 'development' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_environment_label_developement')); ?>

                                    </option>
                                    <option value="qa" <?php echo e(env('APP_ENV') == 'qa' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_environment_label_qa')); ?>

                                    </option>
                                    <option value="production" <?php echo e(env('APP_ENV') == 'production' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_environment_label_production')); ?>

                                    </option>
                                </select>
                                <?php if($errors->has('environment')): ?>
                                    <span class="text-red">
                                        <?php echo e($errors->first('environment')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="contact-form space-x-1 mb-6">
                                <label
                                    class="text-primary block text-sm font-semibold text-gray-700 capitalize mb-5"
                                >
                                    <?php echo e(trans('installer_messages.environment.wizard.form.app_debug_label')); ?>

                                </label>
                                <div class="flex items-center mt-2">
                                    <input
                                        type="radio"
                                        class="h-4 w-4 text-primary border-gray-300 focus:ring-primary cursor-pointer"
                                        name="app_debug"
                                        id="app_debug_true"
                                        value="true"
                                        <?php echo e(env('APP_DEBUG') ? 'checked' : ''); ?>

                                    />
                                    <label
                                        for="app_debug_true"
                                        class="ml-2 block text-sm text-gray-700 cursor-pointer"
                                    >
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_debug_label_true')); ?>

                                    </label>
                                </div>
                                <div class="flex items-center mt-2">
                                    <input
                                        type="radio"
                                        class="h-4 w-4 text-primary border-gray-300 focus:ring-primary cursor-pointer"
                                        name="app_debug"
                                        id="app_debug_false"
                                        value="false"
                                        <?php echo e(!env('APP_DEBUG') ? 'checked' : ''); ?>

                                    />
                                    <label
                                        for="app_debug_false"
                                        class="ml-2 block text-sm text-gray-700 cursor-pointer"
                                    >
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_debug_label_false')); ?>

                                    </label>
                                </div>
                            </div>

                            <div class="contact-form">
                                <label for="app_log_level" class="text-primary block text-sm font-semibold text-gray-700 capitalize">
                                    <?php echo e(trans('installer_messages.environment.wizard.form.app_log_level_label')); ?>

                                </label>
                                <select name="app_log_level" id="app_log_level" class="h-10 px-0 py-3 mt-1 block w-full border-b border-primary outline-none sm:text-sm bg-transparent">
                                    <option value="debug" <?php echo e(env('APP_LOG_LEVEL') == 'debug' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_log_level_label_debug')); ?>

                                    </option>
                                    <option value="info" <?php echo e(env('APP_LOG_LEVEL') == 'info' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_log_level_label_info')); ?>

                                    </option>
                                    <option value="notice" <?php echo e(env('APP_LOG_LEVEL') == 'notice' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_log_level_label_notice')); ?>

                                    </option>
                                    <option value="warning" <?php echo e(env('APP_LOG_LEVEL') == 'warning' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_log_level_label_warning')); ?>

                                    </option>
                                    <option value="error" <?php echo e(env('APP_LOG_LEVEL') == 'error' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_log_level_label_error')); ?>

                                    </option>
                                    <option value="critical" <?php echo e(env('APP_LOG_LEVEL') == 'critical' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_log_level_label_critical')); ?>

                                    </option>
                                    <option value="alert" <?php echo e(env('APP_LOG_LEVEL') == 'alert' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_log_level_label_alert')); ?>

                                    </option>
                                    <option value="emergency" <?php echo e(env('APP_LOG_LEVEL') == 'emergency' ? 'selected' : ''); ?>>
                                        <?php echo e(trans('installer_messages.environment.wizard.form.app_log_level_label_emergency')); ?>

                                    </option>
                                </select>
                                <?php if($errors->has('app_log_level')): ?>
                                    <span class="text-red">
                                        <?php echo e($errors->first('app_log_level')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="contact-form">
                                <label for="app_url" class="text-primary block text-sm font-semibold text-gray-700 capitalize">
                                    <?php echo e(trans('installer_messages.environment.wizard.form.app_url_label')); ?>

                                </label>
                                <input
                                    type="url"
                                    id="app_url"
                                    name="app_url"
                                    class="h-10 px-0 py-3 mt-1 block w-full border-b border-primary outline-none sm:text-sm"
                                    value="<?php echo e(env('APP_URL')); ?>"
                                    placeholder="<?php echo e(trans('installer_messages.environment.wizard.form.app_url_placeholder')); ?>"
                                />
                                <?php if($errors->has('app_url')): ?>
                                    <span class="text-red">
                                        <?php echo e($errors->first('app_url')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="flex gap-4 items-center justify-center">
                        <a
                            href="<?php echo e(route('LaravelInstaller::environment-setting')); ?>"
                            class="btn-primary-outline"
                        >
                            <i class="ri-arrow-left-line"></i>
                            <?php echo e(trans('installer_messages.configurationSetting.previous')); ?>

                        </a>
                        <button class="btn-primary-fill">
                            <?php echo e(trans('installer_messages.configurationSetting.next')); ?>

                            <i class="ri-arrow-right-s-line"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.installer.layouts.imaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/vendor/installer/configuration-setting.blade.php ENDPATH**/ ?>