

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                            <?php echo e(__('Expense Management')); ?>

                        </a>

                    </li>
                    <li class="active">
                        <?php echo e(__('Expense ')); ?>

                    </li>
                </ol>
            </div>

            <div class="row">
                <div class="col-sm-5">
                    <!-- start: DATE/TIME PICKER PANEL -->
                    <div class="panel panel-white">
                        <div class="panel-heading">
                            <h4 class="panel-title text-center"><?php echo e(__('Expense')); ?>  <span class="text-bold"> <?php echo e(__('Create')); ?></span></h4>
                        </div>
                        <div class="panel-body">
                            <form action="<?php echo e(route('expense.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label><?php echo e(__('Date')); ?></label>
                                    <input type="date" name="date" id="Date" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('Category')); ?></label>
                                    <select name="categoryId" id="CategoryId" class="form-control">
                                        <option value=""><?php echo e(__('Select Category')); ?></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('Expense For')); ?></label>
                                    <input type="text" name="expense_for" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('Amount')); ?></label>
                                    <input type="number" name="amount" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('Note')); ?></label>
                                    <textarea name="note" class="form-control"></textarea>
                                </div>
                        
                                <button type="submit" class="btn btn-sm btn-primary">
                                    <?php echo e(__('Create')); ?>

                                </button>
                                <p></p>
                            </form>
                        </div>
                    </div>
                    <!-- end: DATE/TIME PICKER PANEL -->
                </div>
                <div class="col-md-7">
                    <div class="panel panel-white">
                        <div class="panel-body">
                            <h4>Expense  List</h4>
                            <div class="table-responsive">
                                <table class="table table-striped" id="ExpensesTable">
                                    <thead>
                                        <tr>
                                            <th scope="col"<?php echo e(__('ID')); ?></th>
                                            <th scope="col"><?php echo e(__('Date')); ?></th>
                                            <th scope="col"><?php echo e(__('Category')); ?></th>
                                            <th scope="col"><?php echo e(__('Expense For')); ?></th>
                                            <th scope="col"><?php echo e(__('Amount')); ?></th>
                                            <th scope="col"><?php echo e(__('Note')); ?></th>
                                            <th scope="col"><?php echo e(__('Action')); ?></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(__('Edit Expense')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editExpenseForm" method="POST"> 
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="id" id="expenseId">
                        <div class="form-group">
                            <label><?php echo e(__('Date')); ?></label>
                            <input type="date" name="date" id="expenseDate" class="form-control">
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Category')); ?></label>
                            <select name="categoryId" id="expenseCategoryId" class="form-control">
                                <option value=""><?php echo e(__('Select Category')); ?></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Expense For')); ?></label>
                            <input type="text" name="expense_for" id="expenseFor" class="form-control">
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Amount')); ?></label>
                            <input type="number" name="amount" id="expenseAmount" class="form-control">
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Note')); ?></label>
                            <textarea name="note" id="expenseNote" class="form-control"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save changes')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
<!-- Your custom scripts -->
<script>
    $(document).ready(function() {
        // Show success message
        <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>", 'Success');
        <?php endif; ?>
        // Show validation errors
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error("<?php echo e($error); ?>", 'Error');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    });

    // Edit Expense  Modal
    function editExpense(id, date, categoryId, expenseFor, amount, note) {
        var actionUrl = '<?php echo e(url("/expense/update")); ?>/' + id;
        $('#editExpenseForm').attr('action', actionUrl);
        $('#expenseId').val(id);
        $('#expenseDate').val(date);
        $('#expenseCategoryId').val(categoryId);
        $('#expenseFor').val(expenseFor);
        $('#expenseAmount').val(amount);
        $('#expenseNote').val(note);
    }

    // Datatable for Expense Categories
    $('#ExpensesTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('expense.data')); ?>", // Adjust the route to fetch data
        columns: [
            { data: 'id', name: 'id' },
            { data: 'date', name: 'date' },
            { data: 'category', name: 'category' }, // Category name
            { data: 'expense_for', name: 'expense_for' },
            { data: 'amount', name: 'amount' },
            { data: 'note', name: 'note' },
            { data: 'actions', name: 'actions', orderable: false, searchable: false }
        ]
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/expense/index.blade.php ENDPATH**/ ?>