

<?php $__env->startPush('stylesheet'); ?>
<style>
    td{
        padding: 2px !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                            <?php echo e(__('Purchase Management')); ?>

                        </a>
                    </li>
                    <li class="active">
                        <?php echo e(__('Create Purchase')); ?>

                    </li>
                </ol>
            </div>
            <div class="row" style="display:flex;">
                <div class="col-sm-10" style="margin:auto !important;">
                    <div class="panel panel-white">
                        <div class="panel-body">
                            <div class="row" style="padding: 6px;">
                                <form action="" method="GET" id="myform"> <?php echo csrf_field(); ?>
                                    <div class="row bg-secondary p-3">
                                        <div class="col-md-2">
                                            <input type="date" class="form-control" id="fromDate" value="<?php echo e(request()->fromDate); ?>"
                                                name="fromDate">
                                        </div>
                                        <div class="col-md-2">
                                            <input type="date" class="form-control" id="toDate" name="toDate"
                                                value="<?php echo e(request()->toDate); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <select id="supplier" class="form-control single-select" name="supplierId">
                                                <option value=""><?php echo e(__('Select Supplier')); ?></option>
                                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(request()->supplierId == $supplier->id ? 'selected' : ''); ?>

                                                        value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <button id="btn1" type="submit" name="submit" value="search" class="btn btn-sm btn-primary" title="Search"><i class="fa fa-search"></i></button>
                                            <button id="btn2" type="submit" name="submit" value="pdf" target="__blank" class="btn btn-sm btn-warning" title="Download PDF"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></button>
                                            <a href="<?php echo e(route('report.purchase')); ?>" class="btn btn-sm btn-danger" title="Reset"><i class="fa fa-times"></i></a>
                                        </div>
                
                                    </div>
                                </form>
                            </div>
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col"<?php echo e(__('SL')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Date')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Invoice')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Supplier')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Subtotal')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Invoicer Discount')); ?></th>
                                        <th scope="col" class="text-center"><?php echo e(__('Total')); ?></th>
                                    </tr>
                                </thead>
                                <?php
                                    $total = 0;
                                    $totalDiscount = 0;
                                    $payableTotal = 0;
                                    $paidTotal = 0;
                                    $dueTotal = 0;
                                    $subTotal = 0;
                                ?>
                                <tbody>
                                    <?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $total += $subTotal;
                                            $totalDiscount += $data->total_discount;
                                            $payableTotal += $data->total_amount;
                                        ?>
                                        <tr>
                                            <?php
                                                $subTotal = $data->total_discount+$data->total_amount;
                                            ?>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td class="text-bold-500 text-center"><?php echo e(date('j F Y', strtotime($data->invoice_date))); ?>

                                            </td>
                                            <td class="text-center"><?php echo e($data->invoice_no); ?></td>
                                            <td class="text-center"><?php echo e($data?->supplier->name); ?></td>
                                            <td class="text-center"><?php echo e(number_format($subTotal, 2)); ?></td>
                                            <td class="text-center"><?php echo e(number_format($data->total_discount, 2)); ?></td>
                                            <td class="text-center"><?php echo e(number_format($data->total_amount, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="text-center">
                                <?php echo e($dataList->appends(request()->input())->links()); ?>

                            </div>
                            <!-- Professional Summary Card -->
                            <div class="row mt-4">
                                <div class="col-md-12">
                                    <div class="panel panel-white" style="border-left: 4px solid #e74c3c;">
                                        <div class="panel-heading" style="background-color: #f8f9fa; border-bottom: 2px solid #e9ecef;">
                                            <h5 class="panel-title" style="color: #2c3e50; font-weight: 600;">
                                                <i class="fa fa-calculator"></i> <?php echo e(__('Summary (All Matching Records)')); ?>

                                            </h5>
                                        </div>
                                        <div class="panel-body">
                                            <div class="row">
                                                <div class="col-md-4 col-sm-6 mb-3">
                                                    <div class="summary-item" style="text-align: center; padding: 15px; background: #ecf0f1; border-radius: 8px;">
                                                        <small class="text-muted d-block mb-1"><?php echo e(__('Subtotal')); ?></small>
                                                        <h4 class="mb-0" style="color: #34495e; font-weight: 700;"><?php echo e(number_format($grandStats->total_amount + $grandStats->total_discount, 2)); ?></h4>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 mb-3">
                                                    <div class="summary-item" style="text-align: center; padding: 15px; background: #fff3cd; border-radius: 8px;">
                                                        <small class="text-muted d-block mb-1"><?php echo e(__('Invoice Discount')); ?></small>
                                                        <h4 class="mb-0" style="color: #856404; font-weight: 700;"><?php echo e(number_format($grandStats->total_discount, 2)); ?></h4>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-6 mb-3">
                                                    <div class="summary-item" style="text-align: center; padding: 15px; background: #f8d7da; border-radius: 8px; border: 2px solid #e74c3c;">
                                                        <small class="text-muted d-block mb-1"><?php echo e(__('Total Purchase Amount')); ?></small>
                                                        <h4 class="mb-0" style="color: #721c24; font-weight: 700;"><?php echo e(number_format($grandStats->total_amount, 2)); ?></h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
    <script>
        $(document).ready(function() {
            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>
            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            $('#supplier').select2({
                placeholder: "Select an option", // Optional placeholder
                allowClear: true // Allows user to clear selection
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/reports/purchase_report.blade.php ENDPATH**/ ?>