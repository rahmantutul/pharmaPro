

<?php $__env->startPush('stylesheet'); ?>
<style>
    td{
        padding: 2px !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                            Sales Management
                        </a>
                    </li>
                    <li class="active">
                        Sales List
                    </li>
                </ol>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-body">
                            <h4>Sales  <span class="text-bold"> List</span></h4>
                            <div class="table-responsive">
                                <div class="row" >
                                    <form action="" method="GET"> <?php echo csrf_field(); ?>
                                        <div class="form-group col-md-4">
                                            <select id="medList" name="medId" class="form-control single-select">
                                                <option value="">Select Medicine </option>
                                                <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(($item->id == request()->medId) ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?> || <?php echo e($item->strength); ?> || <?php echo e($item->supplier->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-3">
                                            <select id="invoiceList" name="invNo" class="form-control single-select">
                                                <option value="">Select Invoice </option>
                                                <?php $__currentLoopData = $invList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(($item->id == request()->invNo) ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->invoice_no); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-3">
                                            <select id="customerList" name="customer" class="form-control single-select">
                                                <option value="">Select Customer </option>
                                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cust): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(($cust->id == request()->customer) ? 'selected' : ''); ?> value="<?php echo e($cust->id); ?>"><?php echo e($cust->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <button class="btn btn-sm btn-primary" type="submit"><i class="fa fa-search"></i>&nbsp; Search</button>
                                            <a class="btn btn-sm btn-warning" href="<?php echo e(route('sales.order.index')); ?>"><i class="fa fa-times"></i>&nbsp;Clear</a>
                                        </div>
                                    </form>
                                </div>
                                <table class="table table-striped" >
                                    <thead>
                                        <tr>
                                            <th scope="col"><?php echo e(__('#')); ?></th>
                                            <th scope="col"><?php echo e(__('Date')); ?></th>
                                            <th scope="col"><?php echo e(__('Invoice')); ?></th>
                                            <th scope="col"><?php echo e(__('Customer')); ?></th>
                                            <th style="text-align:right;" scope="col"><?php echo e(__('Subtotal')); ?></th>
                                            <th style="text-align:right;" scope="col"><?php echo e(__('Invoice Discount')); ?></th>
                                            <th style="text-align:right;" scope="col"><?php echo e(__('Total')); ?></th>
                                            <th style="text-align:right;" scope="col"><?php echo e(__('Paid Amount')); ?></th>
                                            <th style="text-align:right;" scope="col"><?php echo e(__('Invoice Due')); ?></th>
                                            <th scope="col"><?php echo e(__('Action')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody id="salesTableBody">
                                        <?php echo $__env->make('dashboard.sale.sales_list_partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Start Add Modal -->
                <div class="modal fade" id="medicineModal" tabindex="-1" role="dialog" aria-labelledby="medicineModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="medicineModalLabel"><?php echo e(__('Purchase Details')); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('Image')); ?></th>
                                            <th><?php echo e(__('Med Name')); ?></th>
                                            <th><?php echo e(__('Price')); ?></th>
                                            <th><?php echo e(__('Qty')); ?></th>
                                            <th><?php echo e(__('Subtotal')); ?></th>
                                            <th><?php echo e(__('Discount')); ?></th>
                                            <th><?php echo e(__('Total')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody id="medicineTableBody">
                                        <!-- AJAX loaded data will be inserted here -->
                                    </tbody>
                                </table>
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                    
                </div>
            <!-- End Add Modal -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
    <script>
        // Initialize the first medicine dropdown
        $(`#medList`).select2({
            placeholder: "Select an option",
            allowClear: true
        });

        // Initialize the first medicine dropdown
        $(`#invoiceList`).select2({
            placeholder: "Select an option",
            allowClear: true
        });

        // Initialize the first medicine dropdown
        $(`#customerList`).select2({
            placeholder: "Select an option",
            allowClear: true
        });

        $(document).ready(function() {
            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>
            <?php if(session('errors')): ?>
                toastr.success("<?php echo e(session('errors')); ?>", 'Errors');
            <?php endif; ?>
            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });
    </script>
    <script>
        $(document).ready(function() {
            // event delegation for dynamic content
            $(document).on('click', '.actionButton', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: '<?php echo e(route('sales.order.details', ':id')); ?>'.replace(':id', id),
                    method: 'GET',
                    success: function(data) {
                        var tableBody = $('#medicineTableBody');
                        tableBody.empty();
                        if (data.success && data.details) {
                            data.details.forEach(function(details) {
                                var row = `<tr>
                                                <td><img src="/uploads/images/medicine/${details.medicine.image}" alt="${details.medicine.name}" width="50"> </td>
                                                <td>${details.medicine.name}</td>
                                                <td>${window.APP_CURRENCY} ${details.sell_price}</td>
                                                <td>${details.qty}</td>
                                                <td>${window.APP_CURRENCY} ${details.subtotal}</td>
                                                <td>${details.discount}</td>
                                                <td>${window.APP_CURRENCY} ${details.total}</td>
                                            </tr>`;
                                tableBody.append(row);
                            });
                            $('#medicineModal').modal('show');
                        } else {
                            alert('Failed to load details data.');
                        }
                    },
                    error: function() {
                        alert('Failed to fetch medicine list.');
                    }
                });
            });

            // AJAX Search Logic
            function fetchSalesData() {
                let medId = $('#medList').val();
                let params = {
                    medId: medId,
                    customer: $('#customerList').val()
                };

                // Specific handling for Invoice List which uses text matching in controller
                // If value is present (ID), we get the text. If cleared/empty, send empty string.
                let invVal = $('#invoiceList').val();
                if (invVal) {
                     params.invNo = $('#invoiceList option:selected').text().trim();
                } else {
                     params.invNo = '';
                }

                $.ajax({
                    url: "<?php echo e(route('sales.order.index')); ?>",
                    method: 'GET',
                    data: params,
                    success: function(response) {
                        $('#salesTableBody').html(response);
                    },
                    error: function() {
                        toastr.error('Failed to filter data');
                    }
                });
            }

            // Listen for changes
            $('#medList, #invoiceList, #customerList').on('change', function() {
                fetchSalesData();
            });
            
            $('form').on('submit', function(e) {
                e.preventDefault();
                fetchSalesData();
            });

            // AJAX Pagination link clicks
            $(document).on('click', '#salesTableBody .pagination a', function(e) {
                e.preventDefault();
                let url = $(this).attr('href');
                let medId = $('#medList').val();
                let params = {
                    medId: medId,
                    customer: $('#customerList').val()
                };
                let invVal = $('#invoiceList').val();
                if (invVal) {
                     params.invNo = $('#invoiceList option:selected').text().trim();
                }

                $.ajax({
                    url: url,
                    method: 'GET',
                    data: params,
                    success: function(response) {
                        $('#salesTableBody').html(response);
                        // Scroll top to show new results
                        $('html, body').animate({
                            scrollTop: $(".panel-white").offset().top - 100
                        }, 500);
                    },
                    error: function() {
                        toastr.error('Failed to load page');
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/sale/sales_index.blade.php ENDPATH**/ ?>