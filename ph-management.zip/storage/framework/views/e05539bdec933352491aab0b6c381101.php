

<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sales_invoice.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end: TOOLBAR -->
    <div class="row">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li>
                    <a href="#">
                        <?php echo e(__('Sales')); ?>

                    </a>
                </li>
                <li class="active">
                    <?php echo e(__('Invoice')); ?>

                </li>
            </ol>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="table-responsive">
                    <div id="invoice" class="row">
                        <section
                            style="width: 302px; margin: 10px auto;background-color: #fff; padding:5px;margin-bottom: 70px;height: auto; border-top: 1px solid #000;"
                            id="invoiceArea">
                            <header style="text-align: center; padding-bottom: 0px">
                                <h3 style="font-size: 24px; font-weight: 700; margin: 0; padding: 0;">
                                    <?php echo e($general_setting->appname); ?></h3>
                                <div style="margin-bottom: 5px; line-height: 1;">
                                    <span style="font-size: 12px;"><?php echo e($general_setting->address); ?></span>
                                    <div style="display: block;">
                                        <span style="font-size: 12px;"><?php echo e(__('Mobile')); ?>: <?php echo e($general_setting->phone); ?></span>,
                                        <span style="font-size: 12px;"><?php echo e(__('Email')); ?>: <?php echo e($general_setting->email); ?></span>
                                    </div>
                                </div>
                            </header>
                            <section style="font-size: 12px;  line-height: 1.222; border-top: 1px solid #000;">
                                <table style="width: 100%;">
                                    <tr style=" border-bottom: 1px solid #000;">
                                        <td class="w-30" style="font-size:12px"><span
                                                style="font-size:12px"><b><?php echo e(__('Date')); ?>:</b></span>
                                        </td>
                                        <td style="font-size:12px">
                                            <?php echo e(date('d M, Y h:i A', strtotime($dataInfo->invoice_date))); ?> 
                                        </td>
                                    </tr>
                                    <tr style=" border-bottom: 1px solid #000;">
                                        <td class="w-30" style="font-size:12px"><span
                                                style="font-size:12px"><b><?php echo e(__('Invoice ID')); ?>:</b></span>
                                        </td>
                                        <td style="font-size:12px"><?php echo e($dataInfo->invoice_no); ?></td>
                                    </tr>
                                    <tr style=" border-bottom: 1px solid #000;">
                                        <td class="w-30" style="font-size:12px"><b><?php echo e(__('Customer Name')); ?>:</b></td>
                                        <td style="font-size:12px"><?php echo e($dataInfo->customer?->name); ?></td>
                                    </tr>
                                    <tr style=" border-bottom: 1px solid #000;">
                                        <td class="w-30" style="font-size:12px"><b><?php echo e(__('Phone')); ?>:</b></td>
                                        <td style="font-size:12px"><?php echo e($dataInfo->customer?->phone); ?></td>
                                    </tr>
                                    <tr style=" border-bottom: 1px solid #000;">
                                        <td class="w-30" style="font-size:12px"><b><?php echo e(__('Address')); ?>:</b></td>
                                        <td style="font-size:12px"><?php echo e($dataInfo->customer?->address); ?></td>
                                    </tr>
                                </table>
                            </section>
                            <h4 style="font-size: 18px; font-weight: 700; text-align: center; margin: 5px 0 0px 0; padding: 0px 0;">
                                <?php echo e(__('INVOICE')); ?></h4>

                            <section style="line-height: 1.23; border-top: 1px solid #000;">
                                <table style="width: 100%">
                                    <thead>
                                        <tr style=" border-bottom: 1px solid #000; font-weight: 700;">
                                            <th class="w-10 text-center" style="font-size: 12px; text-align: center"><?php echo e(__('Sl.')); ?>

                                            </th>
                                            <th class="w-40" style="font-size: 12px;"><?php echo e(__('Name')); ?></th>
                                            <th class="w-15 text-center" style="font-size: 12px; text-align: center"><?php echo e(__('Qty')); ?>

                                            </th>
                                            <th class="w-15 text-right" style="font-size: 12px; text-align: center">
                                                <?php echo e(__('Price')); ?></th>
                                            <th class="w-20 text-right"
                                                style="border-bottom: none; font-size: 12px; text-align: center"><?php echo e(__('Total')); ?>

                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $dataInfo->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr style=" border-bottom: 1px solid #000;">
                                                <td class="text-center"
                                                    style="vertical-align: top; font-size: 12px; text-align: center">
                                                    <?php echo e($key + 1); ?></td>
                                                <td style="vertical-align: top; font-size: 12px; text-align: center">
                                                    <?php echo e($item->medicine->name); ?> </td>
                                                <td class="text-center"
                                                    style="vertical-align: top; font-size: 12px; text-align: center">
                                                    <?php echo e($item->qty); ?> </td>
                                                <td class="text-right"
                                                    style="vertical-align: top; font-size: 12px; text-align: center">
                                                    <?php echo e($general_setting->currency); ?> <?php echo e($item->sell_price); ?></td>
                                                <td
                                                    class="text-right" style="border-bottom: none;vertical-align: top;font-size: 12px;text-align: center ">
                                                    <?php echo e($general_setting->currency); ?> <?php echo e($item->total); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </section>
                            <section
                                style="line-height: 1.23; font-size: 12px; border-top: 1px solid #000; border-top: 1px solid #000;">
                                <table style="width: 93%; margin-right: 7%">
                                    <tr style="  border-bottom: 1px solid #000;">
                                        <td style="text-align: right; font-size: 12px; width: 70%"><?php echo e(__('Sub Total')); ?>:</td>
                                        <td style="text-align: right; font-size: 12px; width: 70%">
                                            <?php echo e($general_setting->currency); ?>

                                            <?php echo e(number_format($dataInfo->grand_total, 2)); ?></td>
                                    </tr>
                                    <tr style="  border-bottom: 1px solid #000;">
                                        <td style="text-align: right; font-size: 12px; width: 70%"><?php echo e(__('Discount')); ?>:</td>
                                        <td style="text-align: right; font-size: 12px; width: 70%">
                                            <?php echo e($general_setting->currency); ?><?php echo e(number_format($dataInfo->invoice_discount, 2)); ?>

                                        </td>
                                    </tr>
                                    <tr style="  border-bottom: 1px solid #000;">
                                        <td style="text-align: right; font-size: 12px; width: 70%"><?php echo e(__('Due')); ?>:</td>
                                        <td style="text-align: right; font-size: 12px; width: 70%">
                                            <?php echo e($general_setting->currency); ?><?php echo e(number_format($dataInfo->due_amount, 2)); ?>

                                        </td>
                                    </tr>

                                    <tr style="  border-bottom: 1px solid #000;">
                                        <td style="text-align: right; font-size: 12px; width: 70%"><?php echo e(__('Grand Total')); ?>:</td>
                                        <td style="text-align: right; font-size: 12px; width: 70%">
                                            <?php echo e($general_setting->currency); ?><?php echo e(number_format($dataInfo->payable_total, 2)); ?>

                                        </td>
                                    </tr>
                                </table>
                            </section>

                            <section
                                style="line-height: 1.222; font-size: 12px; font-style: italic; padding: 0px 0; border-top: 1px solid #000; border-bottom: 1px solid #000;">
                                <span
                                    style="line-height: 1.222; font-size: 12px; font-style: italic; text-transform: uppercase"><b><?php echo e(__('In Text:')); ?>

                                    </b>
                                    <?php echo e(Helper::convert_number_to_words($dataInfo->payable_total)); ?></span><br>
                            </section>
                            <section style="font-size: 12px; line-height: 1.222; text-align: center; padding-top: 0px;">
                                <span style="display: block; font-weight: 700;"><?php echo e(__('Thank you for choosing us!')); ?></span>
                            </section>
                        </section>
                        <div class="row">
                            <div class="col-md-12" style="text-align: center;">
                                <button type="button" onclick="printDiv('invoiceArea')" class="btn print-btn">
                                    <i class="fa fa-print" aria-hidden="true"></i>
                                    <?php echo e(__('Print')); ?>

                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
            // location.reload();
            // Dictionary update of auto print
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('print')) {
                printDiv('invoiceArea');
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/sale/invoice.blade.php ENDPATH**/ ?>