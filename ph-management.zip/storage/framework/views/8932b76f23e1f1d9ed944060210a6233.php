

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                            <?php echo e(__('Expense Management')); ?>

                        </a>

                    </li>
                    <li class="active">
                        <?php echo e(__('Expense Category')); ?>

                    </li>
                </ol>
            </div>

            <div class="row">
                <div class="col-sm-5">
                    <!-- start: DATE/TIME PICKER PANEL -->
                    <div class="panel panel-white">
                        <div class="panel-heading">
                            <h4 class="panel-title text-center"><?php echo e(__('Expense Category')); ?> <span class="text-bold"> <?php echo e(__('Create')); ?></span></h4>
                        </div>
                        <div class="panel-body">
                            <form action="<?php echo e(route('expense.category.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="name" class="form-label"><?php echo e(__('Name')); ?></label>
                                    <input id="name" type="text" class="form-control " name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                </div>
                        
                                <div class="form-group">
                                    <label for="Description" class="form-label"><?php echo e(__('Description')); ?></label>
                                    <input id="Description" type="text" class="form-control " name="description" value="<?php echo e(old('description')); ?>" autofocus>
                                </div>
                        
                                <button type="submit" class="btn btn-sm btn-primary">
                                    <?php echo e(__('Create')); ?>

                                </button>
                                <p></p>
                            </form>
                        </div>
                    </div>
                    <!-- end: DATE/TIME PICKER PANEL -->
                </div>
                <div class="col-md-7">
                    <div class="panel panel-white">
                        <div class="panel-body">
                            <h4>Expense Category List</h4>
                            <div class="table-responsive">
                                <table class="table table-striped" id="ExpenseCategoryTable">
                                    <thead>
                                        <tr>
                                            <th scope="col"><?php echo e(__('ID')); ?></th>
                                            <th scope="col"><?php echo e(__('Name')); ?></th>
                                            <th scope="col"><?php echo e(__('Description')); ?></th>
                                            <th scope="col"><?php echo e(__('Action')); ?></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Expense Category Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="editExpenseCategory" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel"><?php echo e(__('Edit Expense Category')); ?></h5>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="editCustomerName"><?php echo e(__('Name')); ?></label>
                            <input type="text" class="form-control" id="editName" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="editCustomerEmail"><?php echo e(__('Description')); ?></label>
                            <input type="text" class="form-control" id="editDescription" name="description" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save Changes')); ?></button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
<!-- Your custom scripts -->
<script>
    $(document).ready(function() {
        // Show success message
        <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>", 'Success');
        <?php endif; ?>
        // Show validation errors
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error("<?php echo e($error); ?>", 'Error');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    });

    // Edit Expense Category Modal
    function editExpenseCategory(id, name, description) {
        var actionUrl = '<?php echo e(url("/expense/category/update")); ?>/' + id;
        $('#editExpenseCategory').attr('action', actionUrl);
        $('#editName').val(name);
        $('#editDescription').val(description);
    }

    // Datatable for Expense Categories
    $('#ExpenseCategoryTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('expense.category.data')); ?>",
        columns: [
            { data: 'id', name: 'id' },
            { data: 'name', name: 'name' },
            { data: 'description', name: 'description' },
            { data: 'actions', name: 'actions', orderable: false, searchable: false }
        ]
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/expense/category_index.blade.php ENDPATH**/ ?>