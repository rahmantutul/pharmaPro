

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                            <?php echo e(__('Medicine Management')); ?>

                        </a>
                    </li>
                    <li class="active">
                        <?php echo e(__('Medicine')); ?>

                    </li>
                </ol>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <!-- start: DATE/TIME PICKER PANEL -->
                    <div class="panel panel-white">
                        <div class="panel-heading">
                            <h4 class="panel-title text-center"><?php echo e(__('Medicine')); ?> <span class="text-bold">
                                    <?php echo e(__('Create')); ?></span></h4>
                        </div>
                        <div class="panel-body">
                            <form
                                action="<?php echo e(isset($medicine) ? route('medicine.update', $medicine->id) : route('medicine.store')); ?>"
                                method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($medicine)): ?>
                                    <?php echo method_field('PUT'); ?>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="qrcode" class="form-label"><?php echo e(__('QR Code')); ?></label>
                                            <input id="qrcode" type="text" class="form-control" name="qr_code"
                                                value="<?php echo e(old('qr_code', $medicine->qr_code ?? '')); ?>" autofocus>
                                        </div>
                                        <div class="form-group">
                                            <label for="hnscode" class="form-label"><?php echo e(__('HNS Code')); ?></label>
                                            <input id="hnscode" type="text" class="form-control" name="hns_code"
                                                value="<?php echo e(old('hns_code', $medicine->hns_code ?? '')); ?>" autofocus>
                                        </div>
                                        <div class="form-group">
                                            <label for="name" class="form-label"><?php echo e(__('Name')); ?></label>
                                            <input id="name" type="text" class="form-control" name="name"
                                                value="<?php echo e(old('name', $medicine->name ?? '')); ?>" required autofocus>
                                        </div>
                                        <div class="form-group">
                                            <label for="strength" class="form-label"><?php echo e(__('Strength')); ?></label>
                                            <input id="strength" type="text" class="form-control" name="strength"
                                                value="<?php echo e(old('strength', $medicine->strength ?? '')); ?>" autofocus>
                                        </div>
                                        <div class="form-group">
                                            <label for="sell_price" class="form-label"><?php echo e(__('Sell Price')); ?></label>
                                            <input id="sell_price" type="number" class="form-control" step="0.01"
                                                name="sell_price"
                                                value="<?php echo e(old('sell_price', $medicine->sell_price ?? '')); ?>" autofocus>
                                        </div>
                                        <div class="form-group">
                                            <label for="purchase_price"
                                                class="form-label"><?php echo e(__('Purchase Price')); ?></label>
                                            <input id="purchase_price" type="number" class="form-control" step="0.01"
                                                name="purchase_price"
                                                value="<?php echo e(old('purchase_price', $medicine->purchase_price ?? '')); ?>"
                                                autofocus>
                                        </div>
                                        <div class="form-group">
                                            <label for="genericname" class="form-label"><?php echo e(__('Generic Name')); ?></label>
                                            <input id="genericname" type="text" class="form-control" name="generic_name"
                                                value="<?php echo e(old('generic_name', $medicine->generic_name ?? '')); ?>" required
                                                autofocus>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="leafId" class="form-label"><?php echo e(__('Box Size')); ?></label>
                                            <select class="form-control" name="leafId" id="leafId" required>
                                                <option value=""><?php echo e(__('Select Box Size')); ?></option>
                                                <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($leaf->id); ?>"
                                                        <?php echo e(old('leafId', $medicine->leafId ?? '') == $leaf->id ? 'selected' : ''); ?>>
                                                        <?php echo e($leaf->name); ?> (<?php echo e($leaf->qty); ?>)</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="categoryId" class="form-label"><?php echo e(__('Category')); ?></label>
                                            <select class="form-control" name="categoryId" id="categoryId" required>
                                                <option value=""><?php echo e(__('Select Category')); ?></option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($cat->id); ?>"
                                                        <?php echo e(old('categoryId', $medicine->categoryId ?? '') == $cat->id ? 'selected' : ''); ?>>
                                                        <?php echo e($cat->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="vendorId" class="form-label"><?php echo e(__('Vendor')); ?></label>
                                            <select class="form-control" name="vendorId" id="vendorId" required>
                                                <option value=""><?php echo e(__('Select Vendor')); ?></option>
                                                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($vendor->id); ?>"
                                                        <?php echo e(old('vendorId', $medicine->vendorId ?? '') == $vendor->id ? 'selected' : ''); ?>>
                                                        <?php echo e($vendor->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="supplierId" class="form-label"><?php echo e(__('Supplier')); ?></label>
                                            <select class="form-control" name="supplierId" id="supplierId" required>
                                                <option value=""><?php echo e(__('Select Supplier')); ?></option>
                                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($sup->id); ?>"
                                                        <?php echo e(old('supplierId', $medicine->supplierId ?? '') == $sup->id ? 'selected' : ''); ?>>
                                                        <?php echo e($sup->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="typeId" class="form-label"><?php echo e(__('Medicine Type')); ?></label>
                                            <select class="form-control" name="typeId" id="typeId" required>
                                                <option value=""><?php echo e(__('Select Type')); ?></option>
                                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($type->id); ?>"
                                                        <?php echo e(old('typeId', $medicine->typeId ?? '') == $type->id ? 'selected' : ''); ?>>
                                                        <?php echo e($type->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="desc" class="form-label"><?php echo e(__('Description')); ?></label>
                                            <input id="desc" type="text" class="form-control" name="desc"
                                                value="<?php echo e(old('desc', $medicine->desc ?? '')); ?>" autofocus>
                                        </div>
                                        <div class="form-group">
                                            <label for="image" class="form-label"><?php echo e(__('Image')); ?></label><br>
                                            <?php if(isset($medicine) && $medicine->image): ?>
                                                <img src="<?php echo e((file_exists(public_path('uploads/images/medicine/' . $medicine->image)) && !empty($medicine->image)) ? asset('uploads/images/medicine/' . $medicine->image) : asset('uploads/images/medicine/default.png')); ?>"
                                                    alt="Medicine Image" style="height:40px; width:40px;"><br><br>
                                            <?php endif; ?>
                                            <input id="image" type="file" class="form-control" name="image"
                                                <?php echo e(!isset($medicine) ? 'required' : ''); ?> autofocus>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <button type="submit" class="btn btn-sm btn-primary form-control">
                                            <?php echo e(isset($medicine) ? __('Update') : __('Create')); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="panel panel-white">
                        <div class="panel-body">
                            <h4>Medicine <span class="text-bold"><?php echo e(__('List')); ?></span></h4>
                            <div class="table-responsive">
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <input medicine="text" id="medName" class="form-control"
                                            placeholder="Medicine Name">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <select id="medSupplier" class="form-control single-select">
                                            <option value=""><?php echo e(__('Select Supplier')); ?></option>
                                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <select id="medCategory" class="form-control single-select">
                                            <option value=""><?php echo e(__('Select Category')); ?></option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col"><?php echo e(__('ID')); ?></th>
                                            <th scope="col"><?php echo e(__('Image')); ?></th>
                                            <th scope="col"><?php echo e(__('name')); ?></th>
                                            <th scope="col"><?php echo e(__('Generic Name')); ?></th>
                                            <th scope="col"><?php echo e(__('Strength')); ?></th>
                                            <th scope="col"><?php echo e(__('Sell Price')); ?></th>
                                            <th scope="col"><?php echo e(__('Purchase Price')); ?></th>
                                            <th scope="col"><?php echo e(__('Supplier')); ?></th>
                                            <th scope="col"><?php echo e(__('Action')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody id="MedicinesTable">
                                        <?php echo $__env->make('dashboard.medicine.filter_medicine', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
    <script>
        $(document).ready(function() {
            function searchMedicines(page = 1) {
                var medName = $('#medName').val();
                var medSupplier = $('#medSupplier').val();
                var medCategory = $('#medCategory').val();

                $.ajax({
                    url: '<?php echo e(route('medicine.search')); ?>?page=' +
                    page, // Append the page number to the request
                    method: 'GET',
                    data: {
                        medName: medName,
                        medSupplier: medSupplier,
                        medCategory: medCategory
                    },
                    success: function(response) {
                        $('#MedicinesTable').html(response); // Update the table body with the new data
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText); // Log any errors
                    }
                });
            }

            // Trigger search on input or dropdown change
            $('#medName, #medSupplier, #medCategory').on('change keyup', function() {
                searchMedicines();
            });

            // Handle pagination clicks
            $(document).on('click', '.pagination a', function(e) {
                e.preventDefault();
                var page = $(this).attr('href').split('page=')[1];
                searchMedicines(page);
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            //Select 2 plugin 
            $('#medCategory').select2({
                placeholder: "Select an option", // Optional placeholder
                allowClear: true // Allows user to clear selection
            });
            $('#medSupplier').select2({
                placeholder: "Select an option", // Optional placeholder
                allowClear: true // Allows user to clear selection
            });


            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>
            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });

        // Edit Medicine  Modal
        function editMedicine(id, date, categoryId, medicineFor, amount, note) {
            var actionUrl = '<?php echo e(url('/medicine/update')); ?>/' + id;
            $('#editMedicineForm').attr('action', actionUrl);
            $('#medicineId').val(id);
            $('#medicineDate').val(date);
            $('#medicineCategoryId').val(categoryId);
            $('#medicineFor').val(medicineFor);
            $('#medicineAmount').val(amount);
            $('#medicineNote').val(note);
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/medicine/medicine_index.blade.php ENDPATH**/ ?>