

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li><a href="#"><?php echo e(__('Setting Options')); ?></a></li>
                    <li class="active"><?php echo e(__('Software Setup')); ?></li>
                </ol>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-white">
                    <div class="panel-heading">
                        <h4 class="panel-title text-center"><?php echo e(__('Software Settings')); ?> <span class="text-bold"> <?php echo e(__('Update')); ?></span></h4>
                    </div>
                    <div class="panel-body">
                        <form action="<?php echo e(route('settings.update')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="dataId" value="<?php echo e($dataInfo->id); ?>">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="appname" class="form-label"><?php echo e(__('App Name')); ?></label>
                                        <input id="appname" type="text" class="form-control" name="appname"
                                            value="<?php echo e($dataInfo->appname); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="currency" class="form-label"><?php echo e(__('Currency Symbol')); ?></label>
                                        <input id="currency" type="text" class="form-control" name="currency"
                                            value="<?php echo e($dataInfo->currency); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="email" class="form-label"><?php echo e(__('System Email')); ?></label>
                                        <input id="email" type="email" class="form-control" name="email"
                                            value="<?php echo e($dataInfo->email); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone" class="form-label"><?php echo e(__('Phone')); ?></label>
                                        <input id="phone" type="text" class="form-control" name="phone"
                                            value="<?php echo e($dataInfo->phone); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="address" class="form-label"><?php echo e(__('Address')); ?></label>
                                        <input id="address" type="text" class="form-control" name="address"
                                            value="<?php echo e($dataInfo->address); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="expiryalert" class="form-label"><?php echo e(__('Upcoming Expire Alert (Days)')); ?></label>
                                        <input id="expiryalert" type="number" class="form-control" name="expiryalert"
                                            value="<?php echo e($dataInfo->expiryalert); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="lowstockalert" class="form-label"><?php echo e(__('Low Stock Alert (Qty)')); ?></label>
                                        <input id="lowstockalert" type="number" class="form-control"
                                            name="lowstockalert" value="<?php echo e($dataInfo->lowstockalert); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="timeZone" class="form-label"><?php echo e(__('Time Zone')); ?></label>
                                        <select id="timeZone" class="form-control select2" name="timezone" required>
                                            <option value=""><?php echo e(__('Select Time Zone')); ?></option>
                                            <?php $__currentLoopData = $timeZones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($key == $dataInfo->timezone ? 'selected' : ''); ?> value="<?php echo e($key); ?>">
                                                    <?php echo e($key); ?> -- <?php echo e($zone); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="logo" class="form-label"><?php echo e(__('Software Logo')); ?></label><br>
                                        <?php if($dataInfo->logo): ?>
                                            <div style="background: #333; display: inline-block; padding: 15px; border-radius: 8px; margin-bottom: 10px;">
                                                <img style="height:45px; width: auto; object-fit: contain;"
                                                    src="<?php echo e(asset('uploads/images/settings/' . $dataInfo->logo)); ?>"
                                                    alt="Logo">
                                            </div>
                                        <?php endif; ?>
                                        <input id="logo" type="file" class="form-control" name="logo">
                                        <small class="text-muted">Recommended: Transparent PNG (approx. 300x80px)</small>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="mail_driver" class="form-label"><?php echo e(__('Mail Driver')); ?> (e.g., smtp)</label>
                                        <input id="mail_driver" type="text" class="form-control"
                                            name="mail_driver" value="<?php echo e($dataInfo->mail_driver); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="mail_host" class="form-label"><?php echo e(__('Mail Host')); ?></label>
                                        <input id="mail_host" type="text" class="form-control" name="mail_host"
                                            value="<?php echo e($dataInfo->mail_host); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="mail_port" class="form-label"><?php echo e(__('Mail Port')); ?></label>
                                        <input id="mail_port" type="text" class="form-control" name="mail_port"
                                            value="<?php echo e($dataInfo->mail_port); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="mail_username" class="form-label"><?php echo e(__('Mail Username')); ?></label>
                                        <input id="mail_username" type="text" class="form-control"
                                            name="mail_username" value="<?php echo e($dataInfo->mail_username); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="mail_password" class="form-label"><?php echo e(__('Mail Password')); ?></label>
                                        <input id="mail_password" type="text" class="form-control"
                                            name="mail_password" value="<?php echo e($dataInfo->mail_password); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="mail_encryption" class="form-label"><?php echo e(__('Mail Encryption')); ?> (tls/ssl)</label>
                                        <input id="mail_encryption" type="text" class="form-control"
                                            name="mail_encryption" value="<?php echo e($dataInfo->mail_encryption); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="mail_from_address" class="form-label"><?php echo e(__('Mail From Address')); ?></label>
                                        <input id="mail_from_address" type="email" class="form-control"
                                            name="mail_from_address" value="<?php echo e($dataInfo->mail_from_address); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="mail_from_name" class="form-label"><?php echo e(__('Mail From Name')); ?></label>
                                        <input id="mail_from_name" type="text" class="form-control"
                                            name="mail_from_name" value="<?php echo e($dataInfo->mail_from_name); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="favicon" class="form-label"><?php echo e(__('Favicon')); ?></label><br>
                                        <?php if($dataInfo->favicon): ?>
                                            <div style="background: #f0f0f0; display: inline-block; padding: 10px; border-radius: 8px; margin-bottom: 10px;">
                                                <img style="height:32px; width:32px; object-fit: contain;"
                                                    src="<?php echo e(asset('uploads/images/settings/' . $dataInfo->favicon)); ?>"
                                                    alt="Favicon">
                                            </div>
                                        <?php endif; ?>
                                        <input id="favicon" type="file" class="form-control" name="favicon">
                                        <small class="text-muted">Recommended: 64x64 PNG</small>
                                    </div>
                                    <div style="margin-top: 25px;">
                                        <button type="submit" class="btn btn-primary btn-block btn-lg" style="font-weight: 600;">
                                            <i class="fa fa-save"></i> <?php echo e(__('Save All Changes')); ?>

                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
    <script>
        $(document).ready(function() {
            // Initialize Select2
            if ($.fn.select2) {
                $('#timeZone').select2({
                    placeholder: "<?php echo e(__('Select Time Zone')); ?>",
                    allowClear: true,
                    width: '100%'
                });
            }

            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>

            // Show error message
            <?php if(session('error')): ?>
                toastr.error("<?php echo e(session('error')); ?>", 'Error');
            <?php endif; ?>

            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/settings/index.blade.php ENDPATH**/ ?>