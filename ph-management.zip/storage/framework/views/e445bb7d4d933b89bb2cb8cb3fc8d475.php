<?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($key + 1); ?></td>
        <td>
            <?php
                $imagePath = 'uploads/images/medicine/' . $data->image;
                $displayImage = (file_exists(public_path($imagePath)) && !empty($data->image)) 
                               ? asset($imagePath) 
                               : asset('uploads/images/medicine/default.png');
            ?>
            <img style="height:40px; width:40px; border:1px solid #000;" src="<?php echo e($displayImage); ?>" alt="Medicine Image">
        </td>
        <td class="text-bold-500"><?php echo e($data->name); ?></td>
        <td><?php echo e($data->generic_name); ?></td>
        <td><?php echo e($data->strength); ?></td>
        <td><?php echo e($data->sell_price); ?></td>
        <td><?php echo e($data->purchase_price); ?></td>
        <td><?php echo e($data->supplier ? $data->supplier->name : 'N/A'); ?></td>
        <td>
            <a class="btn btn-xs btn-primary" href="<?php echo e(route('medicine.index', $data->id)); ?>"><i class="fa fa-pencil-square" aria-hidden="true"></i></a>
            <a class="btn btn-xs btn-danger" href="<?php echo e(route('medicine.destroy', $data->id)); ?>" onclick="return confirm('<?php echo e(__('Are you sure you want to delete this medicine?')); ?>')"><i class="fa fa-trash-o icon-trash"></i></a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Pagination links -->
<tr>
    <td colspan="9">
        <?php echo e($medicines->links("pagination::bootstrap-4")); ?>

    </td>
</tr><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/medicine/filter_medicine.blade.php ENDPATH**/ ?>