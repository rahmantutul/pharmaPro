

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('dashboard.layouts.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end: TOOLBAR -->
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li>
                        <a href="#">
                            <?php echo e(__('Customer Management')); ?>

                        </a>

                    </li>
                    <li class="active">
                        <?php echo e(__('Customer')); ?>

                    </li>
                </ol>
            </div>

            <div class="row">
                <div class="col-sm-5">
                    <!-- start: DATE/TIME PICKER PANEL -->
                    <div class="panel panel-white">
                        <div class="panel-heading">
                            <h4 class="panel-title text-center"><?php echo e(__('Customer')); ?> <span class="text-bold">
                                    <?php echo e(__('Create')); ?></span></h4>
                        </div>
                        <div class="panel-body">
                            <form action="<?php echo e(route('customer.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="name" class="form-label"><?php echo e(__('Name')); ?></label>
                                    <input id="name" type="text" class="form-control " name="name"
                                        value="<?php echo e(old('name')); ?>" required autofocus>
                                </div>

                                <div class="form-group">
                                    <label for="email" class="form-label"><?php echo e(__('Email')); ?></label>
                                    <input id="email" type="email" class="form-control " name="email"
                                        value="<?php echo e(old('email')); ?>" required autofocus>
                                </div>

                                <div class="form-group">
                                    <label for="phone" class="form-label"><?php echo e(__('Phone')); ?></label>
                                    <input id="phone" type="text" class="form-control " name="phone"
                                        value="<?php echo e(old('phone')); ?>" required autofocus>
                                </div>
                                
                                <div class="form-group">
                                    <label for="address" class="form-label"><?php echo e(__('Address')); ?></label>
                                    <textarea id="address" class="form-control" name="address" id="" cols="30" rows="10"></textarea>
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary">
                                    <?php echo e(__('Create')); ?>

                                </button>
                                <p></p>
                            </form>
                        </div>
                    </div>
                    <!-- end: DATE/TIME PICKER PANEL -->
                </div>
                <div class="col-md-7">
                    <div class="panel panel-white">
                        <div class="panel-body">
                            <h4>Customer List</h4>
                            <div class="table-responsive">
                                <table class="table table-striped" id="acutomersTable">
                                    <thead>
                                        <tr>
                                            <th scope="col"<?php echo e(__('ID')); ?></th>
                                            <th scope="col"><?php echo e(__('Name')); ?></th>
                                            <th scope="col"><?php echo e(__('Email')); ?></th>
                                            <th scope="col"><?php echo e(__('Phone')); ?></th>
                                            <th scope="col"><?php echo e(__('Address')); ?></th>
                                            <th scope="col"><?php echo e(__('Action')); ?></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Customer Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="editCustomerForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel"><?php echo e(__('Edit Customer')); ?></h5>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="editCustomerName"><?php echo e(__('Name')); ?></label>
                            <input type="text" class="form-control" id="editCustomerName" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="editCustomerEmail"><?php echo e(__('Email')); ?></label>
                            <input type="email" class="form-control" id="editCustomerEmail" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="editCustomerPhone"><?php echo e(__('Phone')); ?></label>
                            <input type="text" class="form-control" id="editCustomerPhone" name="phone" required>
                        </div>
                        <div class="form-group">
                            <label for="editCustomerAddress"><?php echo e(__('Address')); ?></label>
                            <input type="text" class="form-control" id="editCustomerAddress" name="address" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save Changes')); ?></button>
                        <button type="button" class="btn btn-secondary"
                            data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript'); ?>
    <!-- Your custom scripts -->
    <script>
        $(document).ready(function() {
            // Show success message
            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>", 'Success');
            <?php endif; ?>
            // Show validation errors
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>", 'Error');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });

        function editCustomer(id, name, email, phone, address, balance) {
            // Set form action URL
            var actionUrl = '<?php echo e(url('/customer/update')); ?>/' + id;
            $('#editCustomerForm').attr('action', actionUrl);

            // Set values in the modal fields
            $('#editCustomerName').val(name);
            $('#editCustomerEmail').val(email);
            $('#editCustomerPhone').val(phone);
            $('#editCustomerAddress').val(address);
        }
    </script>
    <script>
        $('#acutomersTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('customer.data')); ?>",
            columns: [{
                    data: 'id',
                    name: 'id'
                },
                {
                    data: 'name',
                    name: 'name'
                },
                {
                    data: 'email',
                    name: 'email'
                },
                {
                    data: 'phone',
                    name: 'phone'
                },
                {
                    data: 'address',
                    name: 'address'
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ]
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ph-management\resources\views/dashboard/customers/index.blade.php ENDPATH**/ ?>